import { spawn } from "child_process";

console.log("Panel siap digunakan, silahkan masukan perintah Anda.");
spawn("bash", [], {
  stdio: ["inherit", "inherit", "inherit", "ipc"],
});