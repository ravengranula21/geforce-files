import { smsg } from './lib/simple.js'
import database from './lib/database.js'
import path, { join } from 'path'
import { fileURLToPath } from 'url'
import util from 'util'
import fs, { readFileSync, watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { format } from 'util'

const { proto } = (await import('baileys')).default
const isNumber = x => typeof x === 'number' && !isNaN(x)
const delay = ms => isNumber(ms) && new Promise(resolve => setTimeout(function () {
    clearTimeout(this)
    resolve()
}, ms))

export async function handler(chatUpdate) {  
  this.msgqueque = this.msgqueque || []  
  if (!chatUpdate) return  
  let m = chatUpdate.messages[chatUpdate.messages.length - 1]  
  if (!m) return  
  if (m.message?.viewOnceMessageV2)  
    m.message = m.message.viewOnceMessageV2.message  
  if (m.message?.documentWithCaptionMessage)  
    m.message = m.message.documentWithCaptionMessage.message  
  if (m.message?.viewOnceMessageV2Extension)  
    m.message = m.message.viewOnceMessageV2Extension.message  
  if (!m.message) return  
    await this.connectionHandler?.(this, m, chatUpdate)  
    if (global.db.data == null)
        await global.loadDatabase()
    try {
        m = smsg(this, m) || m
        if (!m)
            return
        m.exp = 0
        m.limit = false
        try {
          database(this, m);
            } catch (e) {
         if (/(returnoverlimit|timed|timeout|user|item|time)/ig.test(e.message)) return
            console.error(e)
         }
        let usedPrefix
        let _user = global.db.data?.users?.[m.sender]
        const isROwner = [conn.decodeJid(global.conn.user.id),...global.owner.map((a) => a + "@s.whatsapp.net"),].includes(m.sender);
        const isOwner = isROwner || m.fromMe
        const isPrems = global.db.data.users[m.sender].premium;
        const isMods = global.db.data.users[m.sender].moderator;
        const isBans = global.db.data.users[m.sender].banned;
        if (isROwner) {
            db.data.users[m.sender].premium = true;
            db.data.users[m.sender].premiumDate = "PERMANENT";
            db.data.users[m.sender].limit = "Unlimited";
            db.data.users[m.sender].money = "Unlimited";
            db.data.users[m.sender].moderator = true;
            } else if (isPrems) {
            db.data.users[m.sender].limit = "Unlimited";
            } else if (!isROwner && isBans) return;
        if (m.text && !(isMods || isPrems)) {
            let queque = this.msgqueque, time = 1000 * 5
            const previousID = queque[queque.length - 1]
            queque.push(m.id || m.key.id)
            let intervalID = setInterval(async function () {
                if (queque.indexOf(previousID) === -1) clearInterval(intervalID)
                await delay(time)
            }, time)
        }
        if (m.isBaileys)
            return
        const groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : {}
        const participants = m.isGroup ? groupMetadata.participants : []
        const useLid = groupMetadata.addressingMode === 'lid'
        let user = {}
        let bot = {}
        if (m.isGroup) {
         if (useLid) {
         const senderLid = participants.find(p => p.jid === conn.decodeJid(m.sender))?.lid
         const botLid = participants.find(p => p.jid === conn.decodeJid(conn.user.id))?.lid
         user = participants.find(p => p.lid === senderLid) || {}
         bot = participants.find(p => p.lid === botLid) || {}
          } else {
         user = participants.find(u => conn.decodeJid(u.id || u.jid) === conn.decodeJid(m.sender)) || {}
         bot = participants.find(u => conn.decodeJid(u.id || u.jid) === conn.decodeJid(conn.user.id)) || {}
       }
   }
   const isRAdmin = user?.admin === 'superadmin'
   const isAdmin = isRAdmin || user?.admin === 'admin'
   const isBotAdmin = bot?.admin === 'admin' || bot?.admin === 'superadmin'
        if (opts["nyimak"])
            return;
        if (opts["autoread"]) await this.readMessages([m.key]);
        if (global.antiFromme) {
        if (m.fromMe || m.sender === conn.decodeJid(conn.user.jid)) return
        }
        if (!m.fromMe && !isOwner && !isPrems && opts["self"])
           return;
        if (opts["pconly"] && m.chat.endsWith('g.us'))
            return;
        if (opts["gconly"] && !m.fromMe && !m.chat.endsWith("g.us") && !isOwner && !isPrems) return m.reply(`*– Bot tidak dapat diakses di private chat*

Maaf Hanya pengguna premium saja yang dapat mengakses firur di Private bot jika kamu melihat pesan ini berarti kamu hanya pengguna gratis 

Tapi tenang kamu masih bisa akses bot ini di Komunitas ${global.namebot} 

Kamu dapat akses fitur downloader, game, play, ai, dan lain lain sekarang jika bergabung 

*– Bergabung Sekarang :*
${global.sgc}`);
        if (opts["swonly"] && m.chat !== 'status@broadcast')
            return;
        if (typeof m.text !== 'string')
            m.text = ''
        const ___dirname = path.join(path.dirname(fileURLToPath(import.meta.url)), './plugins')
        for (let name in global.plugins) {
            let plugin = global.plugins[name]
            if (!plugin)
                continue
            if (plugin.disabled)
                continue
            const __filename = join(___dirname, name)
            if (typeof plugin.all === 'function') {
                    await plugin.all.call(this, m, {
                        chatUpdate,
                        __dirname: ___dirname,
                        __filename
                    })
            }
            if (!opts['restrict'])
                if (plugin.tags && plugin.tags.includes('admin')) {
                    continue
                }
            const str2Regex = (str) => str.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&");
        let _prefix = plugin.customPrefix
          ? plugin.customPrefix
          : conn.prefix
            ? conn.prefix
            : global.prefix;
        let match = (
          _prefix instanceof RegExp
            ? [[_prefix.exec(m.text), _prefix]]
            : Array.isArray(_prefix)
              ? _prefix.map((p) => {
                  let re =
                    p instanceof RegExp
                      ? p
                      : new RegExp(str2Regex(p));
                  return [re.exec(m.text), re];
                })
              : typeof _prefix === "string"
                ? [
                    [
                      new RegExp(str2Regex(_prefix)).exec(m.text),
                      new RegExp(str2Regex(_prefix)),
                    ],
                  ]
                : [[[], new RegExp()]]
        ).find((p) => p[1]);
        if (typeof plugin.before === "function")
          if (
            await plugin.before.call(this, m, {
              match,
              conn: this,
              participants,
              groupMetadata,
              user,
              bot,
              isROwner,
              isOwner,
              isRAdmin,
              isAdmin,
              isBotAdmin,
              isPrems,
              isBans,
              chatUpdate,
            })
          )
            continue;
        if (typeof plugin !== "function") continue;
        if (opts && match && m) {
          let result =
            ((opts?.["multiprefix"] ?? true) && (match[0] || "")[0]) ||
            ((opts?.["noprefix"] ?? false) ? null : (match[0] || "")[0]);
          usedPrefix = result;
          let noPrefix;
          if (isROwner) {
            noPrefix = !result ? m.text : m.text.replace(result, "");
          } else {
            noPrefix = !result ? "" : m.text.replace(result, "").trim();
          }
          let [command, ...args] = noPrefix.trim().split` `.filter((v) => v);
          args = args || [];
          let _args = noPrefix.trim().split` `.slice(1);
          let text = _args.join` `;
          command = (command || "").toLowerCase();
          let fail = plugin.fail || global.dfail;

          const prefixCommand = !result
            ? plugin.customPrefix || plugin.command
            : plugin.command;
          let isAccept =
            (prefixCommand instanceof RegExp && prefixCommand.test(command)) ||
            (Array.isArray(prefixCommand) &&
              prefixCommand.some((cmd) =>
                cmd instanceof RegExp ? cmd.test(command) : cmd === command,
              )) ||
            (typeof prefixCommand === "string" && prefixCommand === command);
          m.prefix = !!result;
          usedPrefix = !result ? "" : result;
          if (!isAccept) continue;
                m.plugin = name
                if (m.chat in global.db.data.chats || m.sender in global.db.data.users) {
                    let chat = global.db.data.chats[m.chat]
                    let user = global.db.data.users[m.sender]
                }
                if (plugin.rowner && plugin.owner && !(isROwner || isOwner)) { // Both Owner
                    fail('owner', m, this)
                    continue
                }
                if (plugin.rowner && !isROwner) { // Real Owner
                    fail('rowner', m, this)
                    continue
                }
                if (plugin.owner && !isOwner) { // Number Owner
                    fail('owner', m, this)
                    continue
                }
                if (plugin.mods && !isMods) { // Moderator
                    fail('mods', m, this)
                    continue
                }
                if (plugin.premium && !isPrems) { // Premium
                    fail('premium', m, this)
                    continue
                }
                if (plugin.group && !m.isGroup) { // Group Only
                    fail('group', m, this)
                    continue
                } else if (plugin.botAdmin && !isBotAdmin) { // You Admin
                    fail('botAdmin', m, this)
                    continue
                } else if (plugin.admin && !isAdmin) { // User Admin
                    fail('admin', m, this)
                    continue
                }
                if (plugin.private && m.isGroup) { // Private Chat Only
                    fail('private', m, this)
                    continue
                }
               if (plugin.register == true && _user.registered == false) { // Butuh daftar?
                    fail('register', m, this)
                    continue
                }
                m.isCommand = true
                let xp = 'exp' in plugin ? parseInt(plugin.exp) : 15 // XP Earning per command
                if (xp > 200)
                    m.reply('Ngecit -_-') // Hehehe
                    else
                    m.exp += xp
                if (!isPrems && plugin.limit && global.db.data.users[m.sender].limit < plugin.limit * 1) {
                    this.reply(m.chat, `🍗 *Limit command kamu sudah habis!*
⏳ *Silakan tunggu hingga reset limit di jam 00.00 WIB!*
🍰 *Upgrade ke Premium untuk Unlimited Limit!*`, m)
                    continue // Limit habis
                }
                if (plugin.level > user.level) {
                    this.reply(m.chat, `Diperlukan Level ${plugin.level} Untuk Menggunakan Perintah Ini\n*Level Kamu:* ${user.level}`, m)
                    continue // If the level has not been reached
                }
                let extra = {
                    match,
                    usedPrefix,
                    noPrefix,
                    _args,
                    args,
                    command,
                    text,
                    conn: this,
                    participants,
                    groupMetadata,
                    user,
                    bot,
                    isROwner,
                    isOwner,
                    isRAdmin,
                    isAdmin,
                    isBotAdmin,
                    isPrems,
                    chatUpdate,
                    __dirname: ___dirname,
                    __filename
                }
                try {
                    await plugin.call(this, m, extra)
                    if (!isPrems) {
                        m.limit = m.limit || plugin.limit || false
                        if (plugin.limit) return m.reply(`${m.limit * 1} Limit telah digunakan!\n\nTersisa: ${global.db.data.users[m.sender].limit - 1}`)
                        }
                } catch (e) {
                    m.error = e
                    console.error(e)
                    if (e) {
              let text = util.format(e);
              conn.logger.error(text);
              if (text.match("rate-overlimit")) return;
              if (e.name) {
                for (let jid of owner) {
                  let data = (await conn.onWhatsApp(jid))[0] || {};
                  if (data.exists)
                    this.reply(
                      data.jid,
                      `*[ REPORT ERROR ]*
*• Name Plugins :* ${m.plugin}
*• From :* @${m.sender.split("@")[0]} *(wa.me/${m.sender.split("@")[0]})*
*• Jid Chat :* ${m.chat} 
*• Command  :* ${usedPrefix + command}
*• Error Log :*
\`\`\`${text}\`\`\`
`.trim(),
                      m,
                    );
                }
                m.reply(global.error);
              }
              m.reply(e);
            }
                } finally {
                    if (typeof plugin.after === 'function') {
                        try {
                            await plugin.after.call(this, m, extra)
                        } catch (e) {
                            console.error(e)
                        }
                    }
                }
                break
            }
        }
    } catch (e) {
        console.error(e)
    } finally {
        if (opts['queque'] && m.text) {
            const quequeIndex = this.msgqueque.indexOf(m.id || m.key.id)
            if (quequeIndex !== -1)
                this.msgqueque.splice(quequeIndex, 1)
        }
        let user, stats = global.db.data.stats
        if (m) {
            if (m.sender && (user = global.db.data.users[m.sender])) {
                user.exp += m.exp
                user.limit -= m.limit * 1
            }
            let stat
            if (m.plugin) {
              let rn = ['recording','composing']
              let jd = rn[Math.floor(Math.random() * rn.length)]
              await this.sendPresenceUpdate(jd,m.chat)
                let now = +new Date
                if (m.plugin in stats) {
                    stat = stats[m.plugin]
                    if (!isNumber(stat.total)) stat.total = 1
                    if (!isNumber(stat.success)) stat.success = m.error != null ? 0 : 1
                    if (!isNumber(stat.last)) stat.last = now
                    if (!isNumber(stat.lastSuccess)) stat.lastSuccess = m.error != null ? 0 : now
                } else stat = stats[m.plugin] = {
                    total: 1,
                    success: m.error != null ? 0 : 1,
                    last: now,
                    lastSuccess: m.error != null ? 0 : now
                }
                stat.total += 1

                if (m.isGroup) global.db.data.chats[m.chat].delay = now
                else global.db.data.users[m.sender].delay = now

                stat.last = now
                if (m.error == null) {
                    stat.success += 1
                    stat.lastSuccess = now
                }
            }
        }

        try {
    if (!opts['noprint']) 
        await (await import(`./lib/print.js`)).default(m, this)
    } catch (e) {
     console.log(m, m.quoted, e)
   }
   try {
    const system = (await import('./lib/system.js')).default
     await system(m, this)
      } catch (e) {
  }
 }
}
export async function participantsUpdate({ id, participants, action }) {
    if (opts['self'])
        return
    if (this.isInit)
        return
    if (global.db.data == null)
        await loadDatabase()
    let chat = global.db.data.chats[id] || {}
    let text = ''
    switch (action) {
        case 'add':
        case 'remove':
		case 'leave':
		case 'invite':
		case 'invite_v4':
                if (chat.welcome) {
                    let groupMetadata = await this.groupMetadata(id) || (conn.chats[id] || {}).metadata
                    for (let user of participants) {
                        let pp = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9mFzSckd12spppS8gAJ2KB2ER-ccZd4pBbw&usqp=CAU'
                        try {
                             pp = await this.profilePictureUrl(user, 'image')
                        } catch (e) {
                        } finally {
                            text = (action === 'add' ? (chat.welcome || this.welcome || conn.welcome || 'Welcome, @user!').replace('@subject', await this.getName(id)).replace('@desc', groupMetadata.desc ? groupMetadata.desc.toString() : '') :
                          (chat.bye || this.bye || conn.bye || 'Bye, @user!')).replace('@user', '@' + user.split('@')[0])
                            this.sendMessage(id, {
                            text: text,
                            contextInfo: {
			    mentionedJid: [user],
                            externalAdReply: {  
                            title: action === 'add' ? '© Welcome Message' : '© Leaving Message',
                            thumbnailUrl: pp,
                            sourceUrl: global.sgc,
                            mediaType: 1,
                            renderLargerThumbnail: true 
                            }}}, { quoted: null})
                        }
                    }
                }
                break;
        case "promote": {
                text =
                    chat.sPromote ||
                    this.promote ||
                    conn.promote ||
                    "@user has been promoted as admin!";
                text = text
                    .replace("@subject", await this.getName(id))
                    .replace("@desc", groupMetadata.desc?.toString() || "unknown")
                    .replace("@user", user);
                msgOptions = {
                    text: text.trim(),
                    contextInfo: {
                        mentionedJid: [user],
                        externalAdReply: {
                            title: "˚ ༘✦ ִֶ 𓂃⊹ 𝗣𝗿𝗼𝗺𝗼𝘁𝗲",
                            body: global.wm,
                            thumbnailUrl: pp,
                            sourceUrl: sgc,
                            mediaType: 1,
                            renderLargerThumbnail: true,
                        },
                    },
                };
                break;
            }
        case "demote": {
                text = chat.sDemote || this.demote || conn.demote || "@user is no longer an admin.";
                text = text
                    .replace("@subject", await this.getName(id))
                    .replace("@desc", groupMetadata.desc?.toString() || "unknown")
                    .replace("@user", user);
                msgOptions = {
                    text: text.trim(),
                    contextInfo: {
                        mentionedJid: [user],
                        externalAdReply: {
                            title: "˚ ༘✦ ִֶ 𓂃⊹ 𝗗𝗲𝗺𝗼𝘁𝗲",
                            body: global.wm,
                            thumbnailUrl: pp,
                            sourceUrl: global.sgc,
                            mediaType: 1,
                            renderLargerThumbnail: true,
                        },
                    },
                };
                break;
            }
    }
};

global.dfail = (type, m, conn) => {
    let msg = {
        owner: `┌─⭓「 *OWNER ONLY* 」
│ *• Msg :* this feature only for OWNER 😹!
└───────────────⭓`,
        mods: `┌─⭓「 *MODERATOR ONLY* 」
│ *• Msg :* fitur ini hanya untuk moderator bot!
└───────────────⭓`,
        premium: `┌─⭓「 *PREMIUM ONLY* 」
│ *• Msg :* fitur ini hanya untuk admin grup!
└───────────────⭓`,
        group: `┌─⭓「 *GROUP ONLY* 」
│ *• Msg :* fitur ini hanya untuk grup!
└───────────────⭓`,       
        private: `┌─⭓「 *PRIVATE ONLY* 」
│ *• Msg :* fitur ini hanya untuk private chat!
└───────────────⭓`,
        botAdmin: `┌─⭓「 *BOT NOT ADMIN* 」
│ *• Msg :* fitur ini hanya dapat digunakan jika bot telah menjadi admin!
└───────────────⭓`,
        admin: `┌─⭓「 *ADMIN ONLY* 」
│ *• Msg :* fitur ini hanya untuk admin grup!
└───────────────⭓`,
        restrict: `┌─⭓「 *BLOCK COMMAND* 」
│ *• Msg :* maaf fitur telah diblokir !
└───────────────⭓`,
        register: `┌─⭓「 *REGISTER SEBELUM MENGGUNAKAN BOT* 」
│ • .daftar yourname.29
└───────────────⭓
if you first register on this bot you 
will get additional rewards !

* *Limit :* +20
* *Money :* +20000`
    }[type];
  if (msg)
    return conn.sendMessage(
      m.chat,
      {
        text: msg,
        contextInfo: {
          externalAdReply: {
            title: "Access Denied !",
            body: global.wm,
            thumbnailUrl: global.denied,
            sourceUrl: null,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      },
      { quoted: m }
    );
};