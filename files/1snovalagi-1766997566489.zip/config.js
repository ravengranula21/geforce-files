import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import Function from "./lib/func.js"
import { fileURLToPath } from 'url'

/*--------[ OWNER SETTING ]------------*/
global.owner = ["6281949448422"];//Nomor owner 
global.nameowner = 'fhrz'; // Nama Owner
global.numberbot = '6287737764083'; //Nomor Bot
global.nomorown = '6281949448422'; //Nomor Owner 

/*--------[ BOT SETTINGS ]------------*/
global.namebot = 'Snova';
global.italic = "𝘴𝘯𝘰𝘷𝘢"
global.wm = `© 𝘴𝘯𝘰𝘷𝘢`;
global.wait = '*( Loading )* Tunggu Sebentar...';
global.error = "*[ system notice ]* Terjadi kesalahan pada bot !";
global.done = '*© 𝘴𝘯𝘰𝘷𝘢*';
global.packname = '🍃𝘴𝘯𝘰𝘷𝘢';
global.author = '';

/*--------[ LINK SETTINGS ]------------*/
global.sgc = "https://chat.whatsapp.com/DwiyKDLAuwjHqjPasln3WP";
global.sourceUrl = "https://chat.whatsapp.com/DwiyKDLAuwjHqjPasln3WP";
global.gc = 'https://chat.whatsapp.com/DwiyKDLAuwjHqjPasln3WP';
global.sch = 'https://whatsapp.com/channel/0029VbA6ZQp72WTpwhiTlo3W';

/*--------[ THUMBNAIL SETTING ]------------*/
global.thumb = "https://api.deline.web.id/kfZYXyk300.jpg";
global.denied = "https://pomf2.lain.la/f/cn9jetwf.jpg";

/*--------[ API SETTING ]------------*/
global.lol = "RyAPI";

/*--------[ QUOTED SETTINGS ]------------*/
global.fakestatus = (txt) => {
  return {
    key: {
      remoteJid: "0@s.whatsapp.net",
      participant: "0@s.whatsapp.net",
      id: "",
    },
    message: {
      conversation: txt,
    },
  };
};

global.fkontak = {
  key: {
    participants: "6285822146627@s.whatsapp.net",
    remoteJid: "status@broadcast",
    fromMe: false,
    id: "Halo",
  },
  message: {
    contactMessage: {
      vcard: `BEGIN:VCARD
      VERSION:3.0
      N:Sy;Bot;;;
      FN:y
      item1.TEL;waid='6285822146627':'6285822146627'
      item1.X-ABLabel:Ponsel
      END:VCARD`,
    },
  },
  participant: "6285822146627@s.whatsapp.net",
};
/*-------[ FUNCTION SETTINGS ]-------*/
global.Func = Function;
global.antiFromme = false;

/*-------[ MESSAGE SETTINGS ]-------*/
global.idsaluran = '120363414329890254@newsletter';
global.textsaluran = `© ${global.namebot} - Bot`;

/*-------[ RPG SETTINGS ]----------*/
global.dash = "✧────···[ *SnovaBot* ]···────✧";
global.htki = "*––––––『"; // Hiasan Titile (KIRI)
global.htka = "』––––––*"; // Hiasan Title  (KANAN)
global.multiplier = 100;
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase();
    let emot = {
      exp: "✨",
      money: "🪙",
      potion: "🥤",
      diamond: "💎",
      common: "📦",
      uncommon: "🎁",
      mythic: "🗳️",
      legendary: "🗃️",
      pet: "🎁",
      sampah: "🗑",
      armor: "🥼",
      sword: "⚔️",
      kayu: "🪵",
      batu: "🪨",
      string: "🕸️",
      kuda: "🐎",
      kucing: "🐈",
      anjing: "🐕",
      petFood: "🍖",
      gold: "👑",
      emerald: "💚",
    };
    let results = Object.keys(emot)
    .map((v) => [v, new RegExp(v, "gi")])
    .filter((v) => v[1].test(string));
    if (!results.length) return "";
    else return emot[results[0][0]];
  },
};
/*-----[ Akhir config.js ]-----*/
let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
