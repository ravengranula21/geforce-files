Kasumi Shirogane
Bot WhatsApp menggunakan Node.js dan Baileys
Deskripsi
Kasumi Shirogane adalah bot WhatsApp yang dibuat menggunakan Node.js dan Baileys. Bot ini dapat menangani pesan masuk dan mengirim balasan berdasarkan perintah yang diterima.
Fitur
- Menangani pesan masuk dan mengirim balasan
- Mendukung perintah dasar seperti `.menu`, `.ping`, dll.
Instalasi
1. Clone repository ini menggunakan Git: `git clone https://github.com/Fahrizal62/kasumi-shirogane.git`
2. Masuk ke direktori project: `cd kasumi-shirogane`
3. Instal dependencies: `npm install`
4. Jalankan bot: `npm start`
Kontribusi
Kontribusi sangat dihargai! Jika Anda ingin berkontribusi, silakan buat pull request ke branch `main`.
Lisensi
MIT License
Informasi
- Nama Project: Kasumi Shirogane
- Creator: Fahri
- Tipe Script: ESM
- Tanggal Mulai: 10-11-2025
- Bahasa Pemrograman: JavaScript (Node.js)
- Library: Baileys