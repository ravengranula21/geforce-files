  import './config.js';
  import { useMultiFileAuthState, DisconnectReason, fetchLatestWaWebVersion, makeInMemoryStore, makeCacheableSignalKeyStore, Browsers, jidNormalizedUser } from 'baileys'
  import { createRequire } from "module";
  import path, { join } from 'path'
  import { fileURLToPath, pathToFileURL } from 'url'
  import { platform } from 'process'
  import * as ws from 'ws';
  import Boom from '@hapi/boom'
  import fs, { readdirSync, statSync, unlinkSync, existsSync, readFileSync, watch, rmSync } from 'fs';
  import yargs from 'yargs';
  import { spawn, exec } from 'child_process';
  import lodash from 'lodash';
  import chalk from 'chalk'
  import syntaxerror from 'syntax-error';
  import readline from 'readline';
  import { format, promisify } from 'util';
  import chokidar from 'chokidar';
  import { makeWASocket, protoType, serialize } from './lib/simple.js';
  import pino from 'pino';
  const stat = promisify(fs.stat);
  const require = createRequire(import.meta.url);
  const readdir = promisify(fs.readdir);
  const { chain } = lodash
  protoType()
  serialize()

  global.__filename = function filename(pathURL = import.meta.url, rmPrefix = platform !== 'win32') { return rmPrefix ? /file:\/\/\//.test(pathURL) ? fileURLToPath(pathURL) : pathURL : pathToFileURL(pathURL).toString() }; global.__dirname = function dirname(pathURL) { return path.dirname(global.__filename(pathURL, true)) }; global.__require = function require(dir = import.meta.url) { return createRequire(dir) } 
  global.timestamp = {
  start: new Date
   }

  const __dirname = global.__dirname(import.meta.url)
  global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse())
  global.prefix = new RegExp('^[' + (opts['prefix'] || 'z/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.,\\-').replace(/[|\\{}()[\]^$+*?.\-\^]/g, '\\$&') + ']')

  const dbFilePath = path.join(__dirname, 'database.json');
  const defaultDatabase = { users: {}, chats: {}, stats: {}, msgs: {}, sticker: {}, settings: {}, respon: {}, };

  global.db = {
    READ: false,
    data: null,
    async read() {
      try {
        const data = fs.readFileSync(dbFilePath, 'utf-8');
        this.data = JSON.parse(data);
      } catch (error) {
        this.data = null
      }
    },
    async write(data) {
      try {
        fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2));
      } catch (error) {
        console.error('Error writing database file:', error);
      }
    }
  };

  global.loadDatabase = async () => {
    if (!db.READ) {
      setInterval(async () => {
        await db.write(db.data || {});
      }, 2000);
      db.READ = true;
    }
    if (db.data !== null) return;
    db.READ = true;
    await db.read();
    if (db.data === null) {
      db.data = defaultDatabase;
    }
    db.READ = false;
    db.data = { ...defaultDatabase, ...(db.data || {}), };
    db.chain = lodash.chain(db.data);
  };
  loadDatabase();
  
  global.store = {
    readFromFile: (filePath) => {},
    bind: (ev) => {},
    writeToFile: (filePath) => {},
    loadMessage: async (remoteJid, id) => {
      return {};
    },
    contacts: {},
    messages: {},
    groupMetadata: {}
  };
  
  global.authFolder = `sessions`;
  const logger = pino({ timestamp: () => `,"time":"${new Date().toJSON()}"` }).child({ class: 'Fahri' });
  logger.level = 'fatal';
  function createTmpFolder() {
  const folderName = "tmp";
  const folderPath = path.join(__dirname, folderName);
  if (!fs.existsSync(folderPath)) {
  fs.mkdirSync(folderPath);
  console.log(chalk.green.bold(`[ Success ] Folder '${folderName}' berhasil dibuat.`));
   } else {
  console.log(chalk.blue.bold(`[ Exists ] Folder '${folderName}' already exists.`));
    }
  }
  createTmpFolder();
  const { state, saveState, saveCreds } = await useMultiFileAuthState(authFolder);
  const { version, isLatest } = await fetchLatestWaWebVersion();
  const connectionOptions = {
    printQRInTerminal: false,
    syncFullHistory: true,
    markOnlineOnConnect: false,
    connectTimeoutMs: 60000,
    keepAliveIntervalMs: 10000,
    defaultQueryTimeoutMs: 0,
    generateHighQualityLinkPreview: true,
    patchMessageBeforeSending: msg => {
      const hasBtn = msg.buttonsMessage || msg.templateMessage || msg.listMessage;
      return hasBtn
        ? {
            viewOnceMessage: {
              message: {
                messageContextInfo: { deviceListMetadataVersion: 2, deviceListMetadata: {} },
                ...msg
              }
            }
          }
        : msg;
    },
    auth: state,
    browser: Browsers.ubuntu('Edge'),
    logger: pino({ level: 'silent' }),
    version
  }
  global.conn = makeWASocket(connectionOptions);
  conn.isInit = false
  if (!conn.authState.creds.registered) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, });
    const question = (texto) =>
      new Promise((resolver) => rl.question(texto, resolver));
    console.log(
      chalk.blue.bold(
        "[ Question ] Enter your WhatsApp number, example: 628****",
      ),
    );
    const phoneNumber = await question(
      chalk.green.bold(chalk.blue.bold("=> Your Number : ")),
    );
    const code = await conn.requestPairingCode(phoneNumber);
    console.log(
      chalk.green.bold(
        "[ Success ] Your Pairing Code : " +
          code?.match(/.{1,4}/g)?.join("-") || code,
      ),
    );
  }
  
  async function connectionUpdate(update) {
    const { connection, lastDisconnect, isNewLogin } = update;
    global.stopped = connection;
    if (isNewLogin) {
        console.log(chalk.green("[+] First time connected with Device"));
    }
    if (update.qr != 0 && update.qr != undefined) { }
    if (connection == "open") {
      console.log(chalk.yellow.bold(`[ Success ] connect to : ${JSON.stringify(conn.user, null, 2)}`,),);
    }
    let reason = Boom.isBoom(lastDisconnect?.error) ? lastDisconnect.error.output.statusCode : undefined;
    if (connection === "close") {
      if (reason === DisconnectReason.badSession) {
        conn.logger.error(`Bad Sessions !,  delete ${global.authFolder} and connect again`,);
        console.log(reloadHandler(true));
      } else if (reason === DisconnectReason.connectionClosed) {
        conn.logger.warn(`Connection closed, reconnect...`);
        console.log(reloadHandler(true));
      } else if (reason === DisconnectReason.connectionLost) {
        conn.logger.warn(`Connection lost`);
        console.log(reloadHandler(true));
      } else if (reason === DisconnectReason.connectionReplaced) {
        conn.logger.error(`Connection replace`,);
        console.log(reloadHandler(true));
      } else if (reason === DisconnectReason.loggedOut) {
        conn.logger.error(`Connection Logout, please delete & create your sessions`,);
        console.log(reloadHandler(true));
      } else if (reason === DisconnectReason.restartRequired) {
        conn.logger.info(`Reastart required, plese wait...`,);
        console.log(reloadHandler(true));
      } else if (receivedPendingNotifications) {
        console.log(chalk.cyan('[ Notification ] Pending...')); 
      } else if (reason === DisconnectReason.timedOut) {
        conn.logger.warn(`Connection Timeout`);
        console.log(reloadHandler(true));
      } else {
        conn.logger.warn(`Connection close ${reason || ""}: ${connection || ""}`,);
        console.log(reloadHandler(true));
      }
    }
  }
  process.on('uncaughtException', console.error)
  let isInit = true,
        handler = await import('./handler.js');
        global.reloadHandler = async function (restatConn) {
    let Handler = await import(`./handler.js?update=${Date.now()}`).catch(console.error)
    if (Object.keys(Handler || {}).length) handler = Handler;
    if (restatConn) {
      try {
        conn.ws.close();
      } catch { }
      conn = { ...conn, ...makeWASocket(connectionOptions), };
    }
    conn.handler = handler.handler.bind(conn);
    conn.onParticipantsUpdate = handler.participantsUpdate.bind(conn);
    conn.connectionUpdate = connectionUpdate.bind(conn);
    conn.credsUpdate = saveCreds.bind(conn);
    conn.ev.on("messages.upsert", conn.handler, async ({ messages }) => {
      if (!messages.length) return console.log(chalk.yellow.bold("[-] No new messages found"));
      const m = messages[0],
        participant = m.key?.participant;
      store.messages[participant] = store.messages[participant] || [];
      store.messages[participant].push(m);
      if (!m.message || m.key.fromMe) return;
      await conn.readMessages([m.key]);
      if (!Object.keys(store.groupMetadata).length)
        store.groupMetadata = await conn.groupFetchAllParticipating();
      const now = Date.now(),
        messageTime = m.messageTimestamp * 1000;
      if (now - messageTime > maxTimeDiff) return console.log("Pesan terlalu lama, abaikan.");
      const msg = await serialize(m, conn, store);
      if (m.mtype === "protocolMessage") return console.log("Pesan Mystic")
      if (m.mtype === "CIPHERTEXT") return console.log("Pesan Mystic")
    });
    conn.ev.on("group-participants.update", conn.onParticipantsUpdate, async (event) => {
      const metadata = conn.groupMetadata(event.id)
      groupCache.set(event.id, metadata)
    });
    conn.ev.on("connection.update", conn.connectionUpdate);
    conn.ev.on("creds.update", conn.credsUpdate);
    conn.ev.on('contacts.update', update => {
      for (let contact of update) {
        let id = jidNormalizedUser(contact.id);
        if (store && store.contacts) store.contacts[id] = { ...(store.contacts?.[id] || {}), ...(contact || {}) };
      }
    });
    conn.ev.on('contacts.upsert', update => {
      for (let contact of update) {
        let id = jidNormalizedUser(contact.id);
        if (store && store.contacts) store.contacts[id] = { ...(contact || {}), isContact: true };
      }
    });
    conn.ev.on('groups.update', updates => {
      for (const update of updates) {
        const metadata = conn.groupMetadata(updates.id)
        const id = update.id;
        if (store.groupMetadata[id]) {
          store.groupMetadata[id] = { ...(store.groupMetadata[id] || {}), ...(update || {}) };
        }
      }
    });
    return true;
    }
    ;
  console.log(chalk.blue.bold("[ Process ] Load File in Directory plugins"));
  const Ext = [".js", ".cjs"];
  global.plugins = {};
  let Scandir = async (dir) => {
  let subdirs = await readdir(dir);
  let files = await Promise.all(
    subdirs.map(async (subdir) => {
      let res = path.resolve(dir, subdir);
      return (await stat(res)).isDirectory() ? Scandir(res) : res;
    })
   );
   return files.reduce((a, f) => a.concat(f), []);
  };
  async function load(file) {
   if (file.endsWith(".cjs")) {
    delete require.cache[require.resolve(file)];
    return require(file);
     } else {
     const modulePath = `${pathToFileURL(file).href}?update=${Date.now()}`;
     const plugin = await import(modulePath);
     return plugin.default || plugin;
  }
 }

  async function loadAllPlugins() {
   const files = await Scandir("./plugins");
   for (let abs of files) {
    if (!Ext.includes(path.extname(abs))) continue;
   console.log(chalk.yellow.bold(`[ Load ] Checking plugin: ${abs}`));
   const rel = path.relative(process.cwd(), abs);
   global.plugins[rel] = await load(abs);
   }
   console.log(chalk.green.bold(`[ Success ] Success Load ${Object.keys(plugins).length} plugins`));
  }

  await loadAllPlugins();

  const watcher = chokidar.watch(path.resolve("./plugins"), {
  persistent: true,
  ignoreInitial: true,
 });
  watcher
   .on("add", async (abs) => addPlugin(abs))
   .on("change", async (abs) => reloadPlugin(abs))
   .on("unlink", (abs) => deletePlugin(abs));

  async function addPlugin(abs) {
   if (!Ext.includes(path.extname(abs))) return;
   const rel = path.relative(process.cwd(), abs);
   const err = checkSyntax(abs, rel);
   if (err) return;
   try {
    global.plugins[rel] = await load(abs);
    console.log(chalk.green.bold(`[ New ] Detected New Plugins : ${rel}`));
  } catch (e) {
    console.error(chalk.red.bold(`[ Error ] Failed to load plugin ${rel}:`), e);
  }
 }

  async function reloadPlugin(abs) {
  if (!Ext.includes(path.extname(abs))) return;
  const rel = path.relative(process.cwd(), abs);
  const err = checkSyntax(abs, rel);
  if (err) return;
  try {
    global.plugins[rel] = await load(abs);
    console.log(chalk.blue.bold(`[ Change ] Changes code in Plugins : ${rel}`));
  } catch (e) {
    console.error(chalk.red.bold(`[ Error ] Failed to reload plugin ${rel}:`), e);
  }
 }

  function deletePlugin(abs) {
   const rel = path.relative(process.cwd(), abs);
   if (!Ext.includes(path.extname(abs))) return;
   delete global.plugins[rel];
   console.log(chalk.yellow.bold(`[ Delete ] Success Delete : ${rel}`));
 }

  function checkSyntax(abs, rel) {
   const source = fs.readFileSync(abs);
   const err = syntaxerror(
    source,
    rel,
    abs.endsWith(".js")
      ? {
          sourceType: "module",
          ecmaVersion: 2020,
          allowAwaitOutsideFunction: true,
          allowReturnOutsideFunction: true,
          allowImportExportEverywhere: true,
         }
       : {}
    );
   if (err) {
    console.error(chalk.red.bold(`[+] SyntaxError In Plugin ${rel}:\n`, err));
    return true;
    }
    return false;
   }
  reloadHandler()