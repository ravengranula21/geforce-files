import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { createRequire } from 'module'
import { setupMaster, fork } from 'cluster'
import { watchFile, unwatchFile } from 'fs'
import { createInterface } from 'readline'
import yargs from 'yargs'
import CFonts from 'cfonts'
import chalk from 'chalk'
import os from 'os'

const __dirname = dirname(fileURLToPath(import.meta.url))
const require = createRequire(__dirname)
const rl = createInterface(process.stdin, process.stdout)

CFonts.say('SOVIA BOT', {
   font: 'tiny',
   align: 'center',
}), CFonts.say('By: fhrz joestar.', {
   colors: ['system'],
   font: 'console',
   align: 'center',
});

let isRunning = false

function start(file) {
  if (isRunning) return
  isRunning = true

  const args = [join(__dirname, file), ...process.argv.slice(2)]

  setupMaster({
    exec: args[0],
    args: args.slice(1),
  })

  const p = fork()

  p.on('message', (data) => {
    console.log('[RECEIVED]', data)
    switch (data) {
      case 'reset':
        p.process.kill()
        isRunning = false
        start(file)
        break
      case 'uptime':
        p.send(process.uptime())
        break
    }
  })

  p.on('exit', (_, code) => {
    isRunning = false
    console.error('[❌] Terjadi kesalahan:', code)
    if (code === 0) return
    watchFile(args[0], () => {
      unwatchFile(args[0])
      start(file)
    })
  })

  const opts = new Object(
    yargs(process.argv.slice(2)).exitProcess(false).parse()
  )

  if (!opts['test']) {
    if (!rl.listenerCount('line')) {
      rl.on('line', (line) => {
        p.emit('message', line.trim())
      })
    }
  }
}

start('main.js')