//• © Sovia Project
// • Credits : wa.me/6281949448422 [ Fahriganz ]
// • Owner : 6281949448422
// • Fitur : tools/quoted.js

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/
import {
    serializeM
} from '../../lib/simple.js';

let handler = async (m, {
    conn,
    args,
    usedPrefix,
    command
}) => {
    if (!m.quoted) return m.reply(`*• Example:* ${usedPrefix + command} *[reply text]*`)
    let q = serializeM(await m.getQuotedObj())
    if (!q.quoted) return m.reply('```[ ! ] Textnya Mana Jir ?```');
    await q.quoted.copyNForward(m.chat, true)
}
handler.command = /^q$/i
export default handler