import axios from 'axios'

class Web2Apk {
  constructor() {
    this.baseURL = 'https://standalone-app-api.appmaker.xyz'
  }

  async startBuild(url, email) {
    const res = await axios.post(`${this.baseURL}/webapp/build`, { url, email })
    return res.data?.body?.appId
  }

  async buildConfig(url, appId, appName) {
    const logo = 'https://logo.clearbit.com/' + url.replace('https://', '')
    const config = {
      appId,
      appIcon: logo,
      appName,
      isPaymentInProgress: false,
      enableShowToolBar: false,
      toolbarColor: '#03A9F4',
      toolbarTitleColor: '#FFFFFF',
      splashIcon: "https://files.catbox.moe/ne2w1y.jpg"
    }
    const res = await axios.post(`${this.baseURL}/webapp/build/build`, config)
    return res.data
  }

  async getStatus(appId) {
    while (true) {
      const res = await axios.get(`${this.baseURL}/webapp/build/status?appId=${appId}`)
      if (res.data?.body?.status === 'success') return true
      await this.delay(5000)
    }
  }

  async getDownload(appId) {
    const res = await axios.get(`${this.baseURL}/webapp/complete/download?appId=${appId}`)
    return res.data
  }

  async build(url, email, appName) {
    const appId = await this.startBuild(url, email)
    await this.buildConfig(url, appId, appName)
    await this.getStatus(appId)
    return await this.getDownload(appId)
  }

  async delay(ms) {
    return new Promise(res => setTimeout(res, ms))
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  conn.web2apk = conn.web2apk || {}
  let id = m.chat

  if (!text) {
    return m.reply(`*• Example:* ${usedPrefix + command} *[url|email|appname]*`)
  }

  let [url, email, appName] = text.split('|').map(x => x.trim())
  if (!url || !email || !appName) {
    return m.reply(`*• Example:* ${usedPrefix + command} *[url|email|appname]*`)
  }

  if (!url.startsWith('http://') && !url.startsWith('https://')) url = 'https://' + url
  if (!email.includes('@') || !email.includes('.')) return m.reply('❌ Format email tidak valid.')

  if (id in conn.web2apk) return m.reply('⏳ Masih ada proses build berjalan. Harap tunggu.')

  try {
    conn.web2apk[id] = true
    await m.reply(global.wait)

    const builder = new Web2Apk()
    const result = await builder.build(url, email, appName)

    const downloadUrl = result?.body?.buildFile || result?.body?.downloadUrl || result?.body?.keyFile

    if (downloadUrl) {
      await m.reply(`✅ *APK Berhasil Dibuat!*\n\n📱 App: ${appName}\n🔗 Link Download: ${downloadUrl}\n\n📌 Link hanya berlaku selama 24 jam.`)
    } else {
      await m.reply('❌ Build gagal: tidak dapat mengambil link download.')
    }

  } catch (err) {
    console.error('❌ Error:', err.message)
    await m.reply(`❌ Terjadi kesalahan saat build APK:\n${err.message}\n\nCoba gunakan URL yang berbeda atau pastikan website dapat diakses publik.`)
  } finally {
    delete conn.web2apk[id]
  }
}

handler.help = ['web2apk'].map(v => v + ' *[url|email|appname]*')
handler.tags = ['tools'];
handler.command = ["web2apk","buatapk","webapk"];
handler.limit = true
handler.register = true
handler.premium = true

export default handler