import {
    fetch
} from 'undici';
import jsbe from 'js-beautify';
const html = jsbe.html

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command 
}) => {
    if (!text.includes('https://')) return m.reply(`*• Example:* ${usedPrefix + command} *[url]*`);
    new Promise(async (revolse) => {
        await fetch(text).then(async (response) => {
            let mime
            try {
                mime = response.headers.get('content-type').split(';')[0];
            } catch (err) {
                mime = response.headers.get('content-type')
            }

            let body
            if (/html/.test(mime)) {
                body = await response.text();
                const resht = await html(body);
                await conn.sendMessage(m.chat, {
                    document: Buffer.from(resht),
                    mimetype: mime,
                    fileName: 'result.html'
                }, {
                    quoted: m
                });
            } else if (/video/.test(mime)) {
                body = Buffer.from(await response.arrayBuffer());
                await conn.sendMessage(m.chat, {
                    video: body
                }, {
                    quoted: m
                });
            } else if (/image/.test(mime)) {
                body = Buffer.from(await response.arrayBuffer());
                await conn.sendMessage(m.chat, {
                    image: body
                }, {
                    quoted: m
                });
            } else if (/audio/.test(mime)) {
                body = Buffer.from(await response.arrayBuffer());
                await conn.sendMessage(m.chat, {
                    audio: body,
                    mimetype: mime
                }, {
                    quoted: m
                });
            } else {
                body = await response.json();
                await conn.sendMessage(m.chat, {
                    text: JSON.stringify(body)
                }, {
                    quoted: m
                });
            };
        }).catch(async (e) => {
            await m.reply('*• Error: ${e}');
            await console.log('Error', e);
        });
    });
};

handler.help = ['get', 'fetch', 'fetching'].map(v => v + '*[url]*');
handler.tags = ['tools'];
handler.command = /^(get|fetch|fetching)$/i;
handler.limit = true;

export default handler;