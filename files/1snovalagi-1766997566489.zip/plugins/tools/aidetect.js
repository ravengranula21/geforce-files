import axios from 'axios'
import FormData from 'form-data'

const aiTextDetector = {
    analyze: async (aiText) => {
        if (aiText.length === 20000) {
            throw new Error('Apa Apaan Ini Woi😂')
        }

        const news = new FormData()
        news.append('content', aiText)

        const headers = {
            headers: {
                ...news.getHeaders(),
                'Product-Serial': '808e957638180b858ca40d9c3b9d5bd3'
            }
        }

        const headersObject = {
            headers: {
                'Product-Serial': '808e957638180b858ca40d9c3b9d5bd3'
            }
        }

        const {
            data: getJob
        } = await axios.post(
            'https://api.decopy.ai/api/decopy/ai-detector/create-job',
            news,
            headers
        )

        const jobId = getJob.result.job_id

        const {
            data: processResult
        } = await axios.get(
            `https://api.decopy.ai/api/decopy/ai-detector/get-job/${jobId}`,
            headersObject
        )

        const output = processResult.result.output

        const formatted = output.sentences.map((sentence, index) => {
            return `🧠 *Kalimat ${index + 1}:*\n• ${sentence.content.trim()}\n• Skor: ${sentence.score.toFixed(3)}\n• Status: ${sentence.status === 1 ? 'AI_GENERATED' : 'HUMAN_GENERATED'}`
        })

        return formatted.join('\n\n')
    }
}

const handler = async (m, {
    text,
    usedPrefix,
    command
}) => {
    if (!text) throw `*• Example:* ${usedPrefix + command} Aku adalah manusia sejati yang suka makan bakso.`

    try {
        const result = await aiTextDetector.analyze(text)
        m.reply(result)
    } catch (err) {
        m.reply(`⚠️ Terjadi kesalahan:\n\n${err.message}`)
    }
}

handler.help = ['aidetect *[text]*']
handler.tags = ['tools']
handler.command = /^aidetect|aicek$/i

export default handler