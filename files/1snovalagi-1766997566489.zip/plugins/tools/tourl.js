import FormData from 'form-data'
import { fileTypeFromBuffer } from 'file-type'

let handler = async (m, { command, usedPrefix }) => {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ''
  if (!mime) return m.reply(`*• Example:* ${usedPrefix + command}* *[send/reply media]*`)

  const media = await q.download()
  if (!media) return m.reply(`❌ Gagal mendownload media`)

 let { ext } = (await fileTypeFromBuffer(media)) || {}
  if (!ext) {
    ext = mime.split('/')[1] || 'bin'
  }

  const bodyForm = new FormData()
  bodyForm.append('fileToUpload', media, `file.${ext}`)
  bodyForm.append('reqtype', 'fileupload')

  try {
    const res = await fetch('https://catbox.moe/user/api.php', {
      method: 'POST',
      body: bodyForm,
    })

    const link = await res.text()

    if (!/^https?:\/\//i.test(link)) return m.reply(`❌ Upload gagal\n\nRespon: ${link}`)

    m.reply(`*U R L - U P L O A D E R*
    
*• Link :* ${link}
*• Size :* ${(media.length / 1024).toFixed(2)} KB
*• Expired :* No Expired`)
  } catch (e) {
    console.error(e)
    m.reply(`❌ Terjadi error saat upload: ${e.message}`)
  }
}

handler.help = ['tourl'].map(v => v + ' *[send/reply media]*')
handler.tags = ['tools']
handler.command = /^(upload|tourl)$/i

export default handler