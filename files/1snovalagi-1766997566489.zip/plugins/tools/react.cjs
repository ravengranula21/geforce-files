//© Shima-Bot 2024-2025
// • Credits : wa.me/6281949448422 [ Fahriganz ]
// • Owner: 6281949448422

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, {
    text,
    usedPrefix,
    command
}) => {

    if (!(m.quoted && text)) throw `Tag/Reply pesan with caption: ` +
        `${usedPrefix+command} 🤫`
    await conn.sendMessage(m.chat, {
        react: {
            text: text,
            key: m.getQuotedObj().key
        }
    });

}
handler.help = ["react"];
handler.tags = ["tools"];
handler.command = /^(react)$/i;

module.exports = handler;