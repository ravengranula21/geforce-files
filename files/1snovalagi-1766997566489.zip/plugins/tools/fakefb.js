let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, Func.example(usedPrefix, command,"*[text]*"), m);

  let who = m.mentionedJid && m.mentionedJid[0] 
    ? m.mentionedJid[0] 
    : m.fromMe 
      ? conn.user.jid 
      : m.sender;

  let pp = await conn.profilePictureUrl(who, "image")
    .catch(_ => "https://telegra.ph/file/f1ed66b7930885e565d2a.jpg");

  let name = m.name || "Anonymous";

  let apiUrl = `https://api.zenzxz.my.id/maker/fakefb?name=${encodeURIComponent(name)}&comment=${encodeURIComponent(text)}&ppurl=${encodeURIComponent(pp)}`;

  await conn.sendFile(m.chat, apiUrl, "fakefb.jpg", `🌀 Fake FB Comment\n👤 ${name}\n💬 ${text}`, m);
};

handler.help = ["fakefb"].map((a) => a + " *[text]*");
handler.tags = ["tools"];
handler.command = ["fakefb"];

export default handler;