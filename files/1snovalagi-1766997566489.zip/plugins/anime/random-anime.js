let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    let res = await (await fetch(`https://raw.githubusercontent.com/KazukoGans/database/main/anime/${command}.json`)).json();
    let cita = res[Math.floor(Math.random() * res.length)];

    await conn.sendMessage(m.chat, {
      image: { url: cita },
      caption: `*• Result From :* ${command}`,
      footer: `© Random Anime Image`,
      buttons: [
        { buttonId: `${usedPrefix + command}`, buttonText: { displayText: 'NEXT IMAGE' }, type: 1 },
      ],
      headerType: 4
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    m.reply('Failed to fetch image. Try again later.');
  }
};

handler.help = [
  "akira", "akiyama", "asuna", "ayuzawa", "boruto", "chitanda", "chitoge", "deidara", "doraemon",
  "elaina", "emilia", "asuna", "erza", "gremory", "hestia", "hinata", "inori", "itachi", "isuzu",
  "itori", "kaga", "kagura", "kakasih", "kaori", "kaneki", "kosaki", "kotori", "kuriyama", "kuroha",
  "kurumi", "madara", "mikasa", "miku", "minato", "naruto", "natsukawa", "nekohime", "nezuko",
  "nishimiya", "onepiece", "pokemon", "rem", "rize", "sagiri", "sakura", "sasuke", "shina", "shinka",
  "shizuka", "shota", "tomori", "toukachan", "tsunade", "yatogami", "yuki"
].map(a => a + " *[random image]*");

handler.tags = ["anime"];
handler.command = handler.help.map(a => a.split(" ")[0]);
handler.limit = true;

export default handler;