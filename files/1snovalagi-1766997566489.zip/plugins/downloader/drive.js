import axios from 'axios';

const handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) return m.reply(`*• Example:* ${usedPrefix + command} *[url drive]*`);

  const url = args[0];
  const fileId = getDriveFileId(url);
  if (!fileId) throw 'URL Google Drive tidak valid';

  try {
    const response = await axios({
      method: 'GET',
      url: `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media&key=AIzaSyAA9ERw-9LZVEohRYtCWka_TQc6oXmvcVU`,
      responseType: 'arraybuffer'
    });

    const buffer = Buffer.from(response.data, 'binary');
    await conn.sendFile(m.chat, buffer, 'file', 'Sukses', m);
  } catch (err) {
    console.error(err);
    throw 'gagal mengunduh woi. pastikan file dapat diakses publik.';
  }
};

handler.help = ['gdrive'].map(v => v + ' *[url drive]*')
handler.tags = ['downloader'];
handler.command = /^gdrive$/i;
handler.limit = true;
handler.premium = false;

export default handler;

function getDriveFileId(url) {
  const match = url.match(/\/d\/([^\/]+)/);
  return match ? match[1] : null;
}