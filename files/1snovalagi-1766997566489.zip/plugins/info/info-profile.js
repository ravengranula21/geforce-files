let handler = async (m, { conn }) => {
let user = global.db.data.users[m.sender]
    
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
    let pp = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://telegra.ph/file/f1ed66b7930885e565d2a.jpg')
    let banned = user.banned ? true : false;
    let block = user.block ? true : false;
    let registered = user.registered ? true : false;
    let isPremium = user.premium ? "√" : "×";
    let premiumExpired = user.premium ? new Date(user.premiumDate).toDateString() : "Not Found";
    let pasangan = user.pasangan ? global.db.data.users[user.pasangan].name : 'Not Have';
    let sahabat = user.sahabat ? '' + global.db.data.users[user.sahabat].name : 'Not Have';
    let username = conn.getName(who)
    var now = new Date() * 1
    let fkon = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` }: {} )}, message: { 'contactMessage': { 'displayName': m.name, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${m.name},;;;\nFN:${m.name},\nitem1.TEL;waid=${who.split('@')[0]}:${who.split('@')[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`, 'jpegThumbnail': pp, thumbnail: pp, sendEphemeral: true }}}
    let caption = `*– User Info*
    
┌ • *Name* : ${user.name}
│ • *Role* : ${user.role}
│ • *Skill* : ${user.skill}
│ • *Level* : ${user.level}
│ • *Money* : ${user.money}
│ • *Bank* : ${user.bank} / ${user.fullatm}
│ • *Limit* : ${user.limit}
└ • *Exp* : ${user.exp}


*– RPG Info*

┌ • *Banned* : ${banned ? 'Yes' : 'No'}
│ • *Blocked* : ${block ? 'Yes' : 'No'}
│ • *Verified* : ${registered ? 'Yes' : 'No'}
│ • *Premium* : ${isPremium}
└ • *Expired* : ${premiumExpired}


*– Life Info*
┌ • *Age* : ${user.age}
│ • *Lovers* : ${pasangan}
└ • *Pekerjaan* : ${user.job}`.trim()
conn.sendMessage(m.chat, {
    text: caption, 
    contextInfo: {
    mentionedJid: [m.sender],
    externalAdReply: {
    title: '🌸 P R O F I L E',
    body: `${user.name} Profile - Rpg Bot`,
    thumbnailUrl: pp,
    mediaType: 1,
    renderLargerThumbnail: true
    }}}, {quoted: fkon})
}
handler.help = ['profile']
handler.tags = ['info']
handler.command = /^(pm|profile|profil|me|my)$/i
handler.banned = false
export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function msToDate(ms) {
    let temp = ms
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    let daysms = ms % (24 * 60 * 60 * 1000);
    let hours = Math.floor((daysms) / (60 * 60 * 1000));
    let hoursms = ms % (60 * 60 * 1000);
    let minutes = Math.floor((hoursms) / (60 * 1000));
    let minutesms = ms % (60 * 1000);
    let sec = Math.floor((minutesms) / (1000));
    return days + " Hari\n" + hours + " Jam\n" + minutes + " Menit";
    // +minutes+":"+sec;
}
