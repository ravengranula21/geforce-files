let handler = async (m) => {
  let totalreg = Object.keys(global.db.data.users).length;
  let rtotalreg = Object.values(global.db.data.users).filter(
    (user) => user.registered == true,
  ).length;
  m.reply(`• Total User In Database : *[ ${rtotalreg}/${totalreg} ]*`);
};
handler.help = ["database", "user"].map((a) => a + " *[check total user]*");
handler.tags = ["info"];
handler.command = ["user", "database"];

export default handler;