import fs from "fs";

const handler = async (m, { conn }) => {
  const fitur = Object.values(global.plugins)
    .filter((v) => v.help && !v.disabled)
    .map((v) => v.help)
    .flat(1);

  const totalFiles = Object.keys(global.plugins).length;
  const totalCommands = fitur.length;

  const message = {
    text: `*+ T O T A L - F E A T U R E S*

*• Total Files :* ${totalFiles}
*• Total Commands :* ${totalCommands}`,
    footer: "👥 Request features chat my *.owner*",
    buttons: [
      { buttonId: '.sc', buttonText: { displayText: '👥 INFO - SCRIPT' }, type: 1 },
    ],
    headerType: 1
  };

  await conn.sendMessage(m.chat, message, { quoted: m });
};

handler.help = ["totalfitur *[get total features]*"];
handler.tags = ["info"];
handler.command = ["totalfitur"];
export default handler;