let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]
  
  await conn.sendMessage(m.chat, {
    text: `*Your ID:* ${user.sn}`,
    footer: `© simple whatsapp bot by ${global.nameown}`,
    buttons: [
      {
        buttonId: `.unreg ${user.sn}`,
        buttonText: { displayText: "UNREGISTER" },
        type: 1,
      },
    ],
    headerType: 1,
  }, { quoted: m })
};

handler.help = ["cekid"].map((a) => a + " *[cek ID pengguna]*");
handler.tags = ["main"];
handler.command = ["cekid", "ceksn"];
handler.register = true;

export default handler;