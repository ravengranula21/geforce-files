//© Shima-Bot 2024-2025
// • Credits : wa.me/6281949448422 [ Fahriganz ]
// • Owner: 6287860644193

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

import moment from 'moment-timezone'

let handler = async (m, {
    conn
}) => {
    const chats = Object.entries(conn.chats)
        .filter(([id, data]) => id.endsWith('@g.us') && data.subject)
        .map(([id, data], i) => `│ ${i + 1}. ${data.subject}\n│    📌 ID: ${id}`)

    const output = `
╭─「 *🤖 Bot Group List* 」
│ Total Grup: ${chats.length}
│ Waktu: ${moment().tz('Asia/Jakarta').format('DD/MM/YY HH:mm:ss')}
├───────────────
${chats.join('\n├───────────────\n')}
╰───────────────
  `.trim()

    m.reply(output)
}

handler.help = ['totalgrup *[info group bot]*']
handler.tags = ['info']
handler.command = ['totalgrup']
handler.limit = true

export default handler