let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text) throw `*• Example :* ${usedPrefix + command} *[url channel]*`
  m.reply(wait)

  const urls = text.match(/https?:\/\/(www\.)?whatsapp\.com\/channel\/[^\s]+/gi) || []
  if (!urls.length) return m.reply("*• URL channel tidak valid!*")

  for (let url of urls) {
    let idch = getIdChannel(url)
    if (!idch) return m.reply("*• Tidak dapat mengambil ID channel dari URL!*")

    try {
      let json = await conn.newsletterMetadata("invite", idch)
      let caption = `*乂 N E W S L E T T E R - I N F O*\n\n${Object.entries(json).map(([k, v]) => `- *${k}* : ${v}`).join("\n")}`
      await conn.sendMessage(m.chat, {
        text: caption,
        ...(json.preview ? { externalAdReply: { title: "Channel Info", body: "Newsletter Preview", thumbnailUrl: "https://pps.whatsapp.net" + json.preview, sourceUrl: url, mediaType: 1, renderLargerThumbnail: true, showAdAttribution: false } } : {})
      }, { quoted: m })
    } catch (e) {
      m.reply("*• Gagal mengambil data channel!*")
    }
  }

  function getIdChannel(url) {
    const match = url.match(/channel\/([^\/?\s]+)/)
    return match ? match[1] : null
  }
}

handler.help = ["ci", "channelinfo", "cekidch"].map(v => v + " *[url channel]*")
handler.tags = ["tools", "info"]
handler.command = /^ci|channelinfo|cekidch$/i

export default handler