import baileys from "baileys"
import moment from "moment-timezone"
import PhoneNum from "awesome-phonenumber"
let regionNames = new Intl.DisplayNames(["en"], {
  type: "region",
});

let handler = async (m, { conn }) => {
  let ownerJids = global.owner.map(a => a + "@s.whatsapp.net")

  // Bagian atas (umum)
  let pan = `*[ MY CREATOR ]*
${await Promise.all(
    global.owner.map(
      async (a, i) =>
        `*${i + 1}.* @${a} *[ ${await conn.getName(a + "@s.whatsapp.net")} ]*`
    )
  ).then(res => res.join("\n"))}

*[ INFORMATION ]*
> • _Jangan Spam nomor Owner *[ Sanksi Blokir ]*_
> • _Jangan Call Nomor Owner *[ Sanksi Blokir ]*_`

  // Card per owner
  let cards = await Promise.all(
    global.owner.map(async (a) => {
      let jid = a + "@s.whatsapp.net"
      let ppUrl
      try {
        ppUrl = await conn.profilePictureUrl(jid, "image")
      } catch {
        ppUrl = "https://telegra.ph/file/24fa902ead26340f3df2c.png"
      }

      // ambil data tambahan
      let name = global.nameowner
      let bio
      try {
        bio = await conn.fetchStatus(jid)
      } catch {
        bio = {}
      }
      let num = jid
      let format = PhoneNum(`+${num.split("@")[0]}`);
      let country = regionNames.of(format.getRegionCode("international"));
      let wea = `*[ This Owner ]*\n\n*° Country :* ${country.toUpperCase()}\n*° Name :* ${name}\n*° Format Number :* ${format.getNumber("international")}\n*° Url Api :* wa.me/${a}\n*° Status :* ${bio?.status || "-"}\n*° Date Status :* ${bio?.setAt ? moment(bio.setAt.toDateString()).locale("id").format("LL") : "-"}`

      return {
        header: baileys.proto.Message.InteractiveMessage.Header.create({
          ...(await baileys.prepareWAMessageMedia(
            { image: { url: ppUrl } },
            { upload: conn.waUploadToServer }
          )),
          title: "",
          gifPlayback: false,
          subtitle: global.nameowner,
          hasMediaAttachment: false,
        }),
        body: { text: wea },
        nativeFlowMessage: {
          buttons: [
            {
              name: "cta_url",
              buttonParamsJson: JSON.stringify({
                display_text: "CHAT ME",
                url: `https://wa.me/${a}`,
                merchant_url: `https://wa.me/${a}`,
              }),
            },
          ],
        },
      }
    })
  )

  let msg = baileys.generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: pan },
            carouselMessage: {
              cards,
              messageVersion: 1,
            },
          },
        },
      },
    },
    { userJid: m.sender }
  )

 msg.message.viewOnceMessage.message.interactiveMessage.contextInfo = {
    mentionedJid: ownerJids,
    stanzaId: m.key.id,
    participant: m.key.participant || m.sender,
    quotedMessage: m.message,
    remoteJid: m.chat,
  }

  await conn.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id,
  })
}

handler.help = ["owner"].map(v => v + " *[Contact owner]*")
handler.tags = ["info"]
handler.command = /^(owner|own|pemilik)$/i

export default handler