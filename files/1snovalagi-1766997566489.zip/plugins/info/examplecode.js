let handler = async (m, { conn }) => {
  await conn.sendAliasMessage(
    m.chat,
    {
      text: `*– Example Code*
Select Your Favorite Type!

1. CJS Modules
2. ESM Modules
   
*© ${global.namebot} - Simple WhatsApp Bot*`,
    },
    [
      {
        alias: "1",
        response: `let handler = async (m, { conn, text, usedPrefix, command }) => {
  // kode anda
}
handler.help = ["Help"]
handler.tags = ["tags menu"]
handler.command = ["command"]

module.exports = handler`,
      },
      {
        alias: "2",
        response: `let handler = async (m, { conn, text, usedPrefix, command }) => {
  // kode anda
}
handler.help = ["Help"]
handler.tags = ["tags menu"]
handler.command = ["command"]

export default handler`,
      },
    ],
    m,
  );
};

handler.help = ["example"].map((a) => a + " *[example code]*");
handler.tags = ["info"];
handler.command = ["example"];

export default handler;