//• © Sovia Project
// • Credits : wa.me/6281949448422 [ Fahriganz ]
// • Owner : 6281949448422
// • Fitur : info/main.js

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/
import moment from 'moment-timezone';
import fs from 'fs';

let handler = async (m, {
    conn,
    args,
    usedPrefix,
    command
}) => {
    let user = global.db.data.users[m.sender];
    const perintah = args[0] || "tags";
    const tagCount = {};
    const tagHelpMapping = {};

    let Styles = (text, style = 1) => {
        const xStr = "abcdefghijklmnopqrstuvwxyz1234567890".split("");
        const yStr = Object.freeze({
            1: "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890",
        });
        const replacer = xStr.map((v, i) => ({
            original: v,
            convert: yStr[style][i]
        }));
        return text
            .toLowerCase()
            .split("")
            .map((v) => replacer.find((x) => x.original === v)?.convert || v)
            .join("");
    };

    Object.keys(global.plugins || {})
        .filter(name => !global.plugins[name].disabled)
        .forEach(name => {
            const plugin = global.plugins[name];
            const tags = Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags];
            const helps = Array.isArray(plugin.help) ? plugin.help : [plugin.help];

            tags.forEach(tag => {
                if (!tag) return;
                if (!tagHelpMapping[tag]) tagHelpMapping[tag] = [];

                helps.forEach(cmd => {
                    tagHelpMapping[tag].push({
                        cmd,
                        limit: plugin.limit || 0,
                        premium: plugin.premium === true || plugin.premium === 1
                    });
                });
            });
        });

    for (let name in global.plugins) {
        let plugin = global.plugins[name];
        if (!plugin || plugin.disabled) continue;
        for (let tag of plugin.tags || []) {
            if (!tagCount[tag]) tagCount[tag] = [];
            tagCount[tag].push(plugin);
        }
    }

    if (perintah === "tags") {
        const daftarTag = Object.keys(tagCount).sort().join('\n •  ' + usedPrefix + command + ' ');
        let totalreg = Object.keys(global.db.data.users).length;
        let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length;

        let fhrz = `${global.namebot} it is an automated whatsapp system that can help you with anything on whatsapp!

_*❏ I N F O  B O T*_

▧  BOT NAME: ${global.namebot}
▧  Platform: ${conn.ws.config.browser[0]}
▧  Type: MD
▧  Database: ${rtotalreg} of ${totalreg}

_*❏ I N F O  U S E R*_

▧  Name: ${user.name}
▧  Device : ${m.device}
▧  Limit: ${user.limit}
▧  Status: ${!global.db.data.users[m.sender].registered ? "Not Registered" : global.owner.includes(m.sender.split("@")[0]) ? "Developer Bot" : global.db.data.users[m.sender].premium ? "Premium User" : "Free User"}

_*❏ L I S T  M E N U*_

 •  ${usedPrefix + command} all
 •  ${usedPrefix + command} ${daftarTag}

© Lightweight WaBot By ${global.nameowner}`;

        return conn.sendMessage(m.chat, {
            document: fs.readFileSync("./package.json"),
            jpegThumbnail: {
                url: global.thumb
            },
            fileName: null,
            fileLength: 99999999999999,
            mimetype: 'application/pdf',
            caption: Styles(fhrz),
            contextInfo: {
                externalAdReply: {
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    sourceUrl: null,
                    thumbnailUrl: global.thumb,
                    title: global.namebot,
                },
                isForwarded: true,
                mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterJid: global.idsaluran,
                    serverMessageId: null,
                    newsletterName: "Sovia - Bot"
                }
            }
        }, {
            quoted: m
        });
    } else if (tagCount[perintah]) {
        const spacedText = t => t.toUpperCase().split('').join(' ');
        const daftarHelp = (tagHelpMapping[perintah] || [])
            .map((Helpitem) => ` ${usedPrefix}${Helpitem.cmd}`)
            .join("\n*│  ◦*");

        let menu2 = `*┌  ◦「 MENU ${(perintah)} 」*
*│  ◦*${daftarHelp}
*└  ◦*

*total menu ${(perintah)}:* ${(tagHelpMapping[perintah] || []).length}`;

        return conn.sendMessage(m.chat, {
            text: Styles(menu2),
            contextInfo: {
                externalAdReply: {
                    title: `© ${global.namebot}-nvme`,
                    thumbnailUrl: global.thumb,
                    sourceUrl: sgc,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, {
            quoted: m
        });
    } else if (perintah === "all") {
        const spaced = s => s.toUpperCase().split('').join(' ');
        let allTagsAndHelp = Object.keys(tagCount).map(tag => {
            let cmds = (tagCount[tag] || [])
                .map(p => (Array.isArray(p.help) ? p.help : [p.help])
                    .map(cmd => `   • ${usedPrefix + cmd}`))
                .flat()
                .join('\n');
            return `  *「 M E N U - ${spaced(tag)} 」*\n\n${cmds}`;
        }).join('\n\n');

        return conn.sendMessage(m.chat, {
            text: Styles(allTagsAndHelp),
            contextInfo: {
                externalAdReply: {
                    title: `© ${global.namebot}-nvme`,
                    thumbnailUrl: global.thumb,
                    sourceUrl: sgc,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, {
            quoted: m
        });
    } else {
        await conn.reply(
            m.chat,
            `*[ MENU ${perintah.toUpperCase()} NOT FOUND ]*\n> • _Ketik *.menu* untuk melihat semua kategori menu atau ketik *.menu all* untuk melihat semua fitur_`,
            m,
        );
    }
}

handler.help = ['menu *[view main menu]*'];
handler.tags = ['main'];
handler.command = /^menu$/i;

export default handler;