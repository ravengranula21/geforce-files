import os from "os"

let handler = async (m, { conn }) => {
  let botRuntime = await Func.toDate(process.uptime() * 1000)
  let osRuntime = await Func.toDate(os.uptime() * 1000)
  let digital = Func.toTime(process.uptime() * 1000)

  let caption = `*[ INFO RUNTIME BOT ]
> • *Bot Runtime:* ${botRuntime}
> • *OS  Runtime:* ${osRuntime}`;

  let imageUrl = `https://og.tailgraph.com/og?fontFamily=Poppins&title=Runtime+Bot&titleTailwind=font-bold%20text-red-600%20text-7xl&stroke=true&text=Time : ${digital}&textTailwind=text-red-700%20mt-4%20text-2xl&textFontFamily=Poppins&logoTailwind=h-8&bgUrl=https%3A%2F%2Fwallpaper.dog%2Flarge%2F272766.jpg&bgTailwind=bg-white%20bg-opacity-30&footer=©+AkiraaBot+2023-2024&footerTailwind=text-grey-600`

  await conn.sendMessage(m.chat, {
    image: { url: imageUrl },
    caption
  }, { quoted: m })
}

handler.help = ["runtime", "uptime"].map(a => a + " *[Runtime bot]*")
handler.tags = ["info"]
handler.command = ["runtime", "uptime"]

export default handler