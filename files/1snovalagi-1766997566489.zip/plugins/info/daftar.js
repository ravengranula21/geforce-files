import fetch from 'node-fetch'
import moment from 'moment-timezone'

let handler = async function (m, { text, usedPrefix, command, args }) {
  let user = global.db.data.users[m.sender]
  let id = await Func.makeId(10);
  if (user.registered === true) return m.reply(`*[ YOU ALREADY REGISTERED ]*`)
  if (!text) return conn.reply(m.chat, Func.example(usedPrefix, command, "*[name.age]*"), m);
  let [name, age] = text.split(".");
  if (!name) return m.reply('*[ ! ] Input Name for name*')
  if (isNaN(age)) return m.reply(`*[ ! ] Input Age for age*`)
  if (age < 5) return m.reply(`*[ ! ] You are too young*`)
  if (age > 30) return m.reply(`*[ ! ] You're too old*`)
  user.registered = true;
  user.age = age;
  user.name = name;
  user.regTime = Date.now();
  user.sn = "SV-" + id;
  let limit = +20
  let money = +2000
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.fromMe ? conn.user.jid : m.sender
  let key = await conn.sendMessage(
          m.chat,
          {
            text: "*[ PROCESS VERIFY.... ]*",
          },
          {
            quoted: m,
          },
        );
        await conn.sendMessage(
          m.chat,
          {
            text: `*[ VERIFY  SUCCESS ]*
*• Name:* ${user.name} *[ @${m.sender.split("@")[0]} ]*
*• Age:* ${user.age} y/o
*• ID:* SV-${id}
*• Register Time :* ${moment.tz(user.regTime, "Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss")}

*✅ Terima kasih telah mendaftar diri dengan bot ini, kami akan menyimpan semua data Anda dengan baik di database kami tanpa kehilangan apa pun*`,
            edit: key.key,
            contextInfo: {
              mentionedJid: [m.sender],
            },
          },
          {
            quoted: m,
          },
        );
}
handler.help = ['daftar'].map(v => v + ' *[name.age]*')
handler.tags = ['main'];
handler.command = ["daftar","register","reg"];

export default handler