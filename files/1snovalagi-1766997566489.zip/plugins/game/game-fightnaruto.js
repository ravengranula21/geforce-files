/*
Takashi Yamada
Case : https://whatsapp.com/channel/0029VaTck0W6GcGMwiq4tQ3k/1337
*/

const delay = (ms) => new Promise((res) => setTimeout(res, ms));
const cooldown = new Map();

async function awaitReplyToMessage(conn, chatId, sender, quotedId, time = 60000) {
  return new Promise((resolve) => {
    const onMessage = (upsert) => {
      const msg = upsert.messages[0];
      if (!msg.message || msg.key.fromMe) return;

      const from = msg.key.remoteJid;
      const participant = msg.key.participant || msg.key.remoteJid;
      const isReplyToCorrectMsg = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === quotedId;
      const isValid = from === chatId && participant === sender && isReplyToCorrectMsg;

      if (isValid) {
        conn.ev.off("messages.upsert", onMessage);
        const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text;
        resolve(text?.trim());
      }
    };

    conn.ev.on("messages.upsert", onMessage);
    setTimeout(() => {
      conn.ev.off("messages.upsert", onMessage);
      resolve(null);
    }, time);
  });
}

const handler = async (m, { conn, usedPrefix }) => {
  const cooldownTime = 10 * 60 * 1000; // 10 menit, delay per command nya biar ngga spam :v
  const userCooldown = cooldown.get(m.sender);
  const now = Date.now();

  if (userCooldown && now - userCooldown < cooldownTime) {
    const remaining = ((cooldownTime - (now - userCooldown)) / 60000).toFixed(1);
    return m.reply(`⏳ Kamu harus menunggu *${remaining} menit* lagi untuk bertarung lagi.`);
  }

  cooldown.set(m.sender, now);

  const tema = "Naruto";
  const background = "https://files.catbox.moe/wv9mfj.jpg";

  const openingMessage = `🌟 *WAR SHINOBI* 🌟\n\nSelamat datang di arena shinobi! Pilih karakter favoritmu dan menangkan pertarungan dengan semangat juang ninja!`;
  await conn.sendMessage(m.chat, {
    image: { url: background },
    caption: openingMessage
  }, { quoted: m });

  await delay(1000);

  const characters = [
    "Naruto", "Sasuke", "Sakura", "Kakashi", "Rock Lee",
    "Neji", "Hinata", "Shikamaru", "Ino", "Choji",
    "Gaara", "Kankuro", "Temari", "Might Guy", "Tenten",
    "Jiraiya", "Tsunade", "Minato", "Kushina", "Kiba",
    "Shino", "Konohamaru", "Yamato", "Sai", "Asuma",
    "Sasori", "Deidara", "Kisame", "Itachi", "Obito",
    "Pain", "Konan", "Kabuto", "Madara", "Zabuza", "Haku"
  ];

  const team1 = characters.slice(0, characters.length / 2);
  const team2 = characters.slice(characters.length / 2);

  const teamMessage = `⚔️ *Tim Konoha:* ${team1.join(", ")}\n\n⚔️ *Tim Akatsuki & musuh:* ${team2.join(", ")}`;
  await conn.sendMessage(m.chat, { text: teamMessage }, { quoted: m });

  await delay(800);

  let charList = characters.map((c, i) => `${i + 1}. ${c}`).join("\n");
  const sent = await conn.sendMessage(m.chat, {
      text:`*Pilih karakter kamu dengan membalas (reply) pesan ini dan ketik nomornya:*\n\n${charList}`},
      { quoted : m});

  const response = await awaitReplyToMessage(conn, m.chat, m.sender, sent.key.id);
  const chosenIndex = parseInt(response) - 1;
  if (isNaN(chosenIndex) || chosenIndex < 0 || chosenIndex >= characters.length) {
    await conn.sendMessage(m.chat, { text: "❌ Pilihan tidak valid. Ulangi perintah." }, { quoted: m });
    return;
  }

  const selectedCharacter = characters[chosenIndex];
  await conn.sendMessage(m.chat, {
    text: `✅ Kamu memilih: *${selectedCharacter}*\nBersiaplah untuk pertarungan sengit di dunia shinobi!`},
   { quoted: m });

  const maxRounds = 5;
  let currentRound = 0;
  let score = {
    [selectedCharacter]: 0,
    musuh: 0
  };

  while (currentRound < maxRounds) {
    await delay(1500);
    const opponents = characters.filter(c => c !== selectedCharacter);
    const randomOpponent = opponents[Math.floor(Math.random() * opponents.length)];
    const winner = Math.random() < 0.5 ? selectedCharacter : randomOpponent;
    const loser = winner === selectedCharacter ? randomOpponent : selectedCharacter;

    if (winner === selectedCharacter) {
      score[selectedCharacter]++;
    } else {
      score.musuh++;
    }

    const roundMsg = `🔥 *Ronde ${currentRound + 1}* 🔥\n*${winner}* mengalahkan *${loser}*!\n\n*Skor Sementara:*\n${selectedCharacter}: ${score[selectedCharacter]}\nMusuh: ${score.musuh}`;
    await conn.sendMessage(m.chat, { text: roundMsg }, { quoted: m });

    currentRound++;
  }

  await delay(1200);

  let finalText = `🏁 *PERTARUNGAN SELESAI* 🏁\n\n*${selectedCharacter}:* ${score[selectedCharacter]}\n*Musuh:* ${score.musuh}\n\n`;
  let rewardMsg = "";

  if (score[selectedCharacter] > score.musuh) {
    finalText += `🎉 Selamat! *${selectedCharacter}* menang dengan semangat ninja sejati!\n`;
    rewardMsg = `+100 Limit & +1000 Money telah ditambahkan!`;
    if (!global.db.data.users[m.sender]) global.db.data.users[m.sender] = { limit: 0, money: 0 };
    global.db.data.users[m.sender].limit += 100;
    global.db.data.users[m.sender].money += 1000;
  } else {
    finalText += `☠️ Sayang sekali, *${selectedCharacter}* telah tewas.\nTetap semangat dan coba lagi nanti!`;
  }

  await conn.sendMessage(m.chat, {
    text: `✨ *Hasil Akhir* ✨\n\n${finalText}${rewardMsg ? "\n\n" + rewardMsg : ""}`
  }, { quoted: m });
};

handler.help = ['fightnaruto'];
handler.tags = ['game'];
handler.command = ['fightnaruto'];
handler.group = true

export default handler;