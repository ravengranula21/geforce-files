let handler = async (m, {
    text
}) => {
    let user = global.db.data.users[m.sender]
    user.afk = +new Date
    user.afkReason = text || ''

    await conn.relayMessage(m.chat, {
    extendedTextMessage: {
        text: `Mendeteksi Afk\n\n- Nama: @${m.sender.split('@')[0]}\n- Alasan: ${text || "Tidak diketahui"}`,
        contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idsaluran, 
                newsletterName: `⌜ 🛑 ADA YANG LAGI AFK ⌟`, 
                serverMessageId: -1 
            },
            externalAdReply: {
                title: `M U L A I  A F K`,
                mediaType: 1,
                previewType: 0,
                renderLargerThumbnail: false,
                thumbnailUrl: `https://files.catbox.moe/me4hsx.webp`
            }
        },
                mentions: [m.sender], } 
}, {quoted: m})
}
handler.help = ['afk'].map(a => a + ' *[reason]*')
handler.tags = ['group']
handler.command = /^afk$/i
handler.group = true

handler.before = async (m) => {
    let user = global.db.data.users[m.sender]
    if (!m.isGroup) return;
    if (user.afk > -1) {
        m.reply(`Kamu telah kembali dari Afk
 
- Alasan: ${user.afkReason ? ' Setelah ' + user.afkReason : ''}
- Selama: ${(new Date - user.afk).toTimeString()}
`.trim())
        user.afk = -1
        user.afkReason = ''
    }

    let jids = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
    for (let jid of jids) {
        let user = global.db.data.users[jid]
        if (!user) return;
        let afkTime = user.afk
        if (!afkTime || afkTime < 0) return;
        let reason = user.afkReason || ''
        m.reply(`Tolong jangan Tag dia.
- Afk: ${reason ? 'Dengan Alasan ' + reason : 'Tanpa Alasan'}
- Selama ${(new Date - afkTime).toTimeString()}`.trim())
    }
}

export default handler