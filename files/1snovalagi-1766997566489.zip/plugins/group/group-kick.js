let handler = async (m, { conn, text, args }) => {
  let users = []

  if (m.quoted) users.push(m.quoted.sender)
  if (m.mentionedJid.length > 0) users.push(...m.mentionedJid)

  if (args[0] && !m.mentionedJid[0]) {
    let number = args[0].replace(/[^0-9]/g, '')
    if (number) users.push(number + '@s.whatsapp.net')
  }

  if (users.length === 0) {
    return m.reply(`*• Example :* .kick *[reply/tag user|628xxx]*`)
  }

  users = users.filter(u => u !== conn.user.jid)

  for (let user of users) {
    await conn.groupParticipantsUpdate(m.chat, [user], 'remove')
      .catch(() => m.reply(`Gagal kick @${user.split('@')[0]}`, { mentions: [user] }))
  }
}

handler.help = ['kick'].map(a => a + ' [reply/tag user|628xxx]')
handler.tags = ['group']
handler.command = /^kick$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler