let handler = async (
  m,
  { isAdmin, isOwner, isBotAdmin, conn, args, usedPrefix, command },
) => {
  let chat = global.db.data.chats[m.chat];
  let prefix = usedPrefix;
  let bu = `*[ ✓ ] Success turned on anti link on this group*`.trim();

  let isClose = {
    on: true,
    off: false,
  }[args[0] || ""];
  if (isClose === undefined) {
    var text5 = `*[ ${command.toUpperCase()} EXAMPLE ]*:
> *• Example :* ${usedPrefix + command} on
> *• Example :* ${usedPrefix + command} off`;
    m.reply(text5);

    throw false;
  } else if (isClose === false) {
    chat.antiLink = isClose;
    await m.reply("*[ ✓ ] Successfully turned off anti link on this group*");
  } else if (isClose === true) {
    chat.antiLink = isClose;
    await m.reply(bu);
  } else if (isClose === undefined) {
    var te = `*[ ${command.toUpperCase()} EXAMPLE ]*:
> *• Example :* ${usedPrefix + command} on
> *• Example :* ${usedPrefix + command} off`;

    m.reply(te);
  }
};

handler.before = async function (m, { conn, isAdmin, isBotAdmin }) {
  if (!m.isGroup || m.isBaileys || m.fromMe) return

  global.db.data.chats = global.db.data.chats || {}
  global.db.data.users = global.db.data.users || {}

  let chat = global.db.data.chats[m.chat] || {}
  let user = global.db.data.users[m.sender] || {}

  const linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i
  const isGroupLink = linkRegex.exec(m.text)

  if (chat.antiLink && isGroupLink) {
    if (isAdmin) return

    const ownGroupLink = 'https://chat.whatsapp.com/' + await conn.groupInviteCode(m.chat)
    const isOwn = new RegExp(ownGroupLink, 'i').test(m.text)
    if (isOwn) return

    user.antilink_warn = (user.antilink_warn || 0) + 1
    const maxWarn = 5

    await conn.sendMessage(m.chat, { delete: m.key })

    await conn.sendMessage(m.chat, {
      text:
        `🚫 *ANTI GROUP LINK DETECTED!*\n\n` +
        `User: @${m.sender.split("@")[0]}\n` +
        `Group links are not allowed in this group.\n` +
        `Warning: ${user.antilink_warn}/${maxWarn}\n\n` +
        (user.antilink_warn >= maxWarn
          ? `❌ You have reached the warning limit and will be removed.`
          : `⚠️ Do not post group links again or you will be removed.`),
      mentions: [m.sender]
    })

    if (user.antilink_warn >= maxWarn) {
      await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove")
      user.antilink_warn = 0
    }

    global.db.data.users[m.sender] = user
  }
}
handler.help = ["antilink"].map(v => v + ' *[on/off]*');
handler.tags = ["group"];
handler.command = ["antilink"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;