//• © Sovia Project
// • Credits : wa.me/6281949448422 [ Fahriganz ]
// • Owner : 6281949448422
// • Fitur : group/group-delete.js

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/
let handler = async (m, {
    conn,
    usedPrefix,
    command
}) => {
    if (!m.quoted) return m.reply(`*• Example :* ${usedPrefix + command} *[reply message]*`)

    let key = {}
    try {
        key.remoteJid = m.quoted.fakeObj?.key?.remoteJid || m.key.remoteJid
        key.fromMe = m.quoted.fakeObj?.key?.fromMe || m.key.fromMe
        key.id = m.quoted.fakeObj?.key?.id || m.key.id
        key.participant = m.quoted.fakeObj?.participant || m.key.participant
    } catch (e) {
        console.error(e)
    }

    await conn.sendMessage(m.chat, {
        delete: key
    })
}

handler.help = ['delete', 'del'].map(v => v + ' *[reply message]*')
handler.tags = ['group']
handler.command = /^(delete|del|hapus)$/i
handler.botAdmin = true

export default handler