let handler = async (
  m,
  { isAdmin, isOwner, isBotAdmin, conn, args, usedPrefix, command }
) => {
  let chat = global.db.data.chats[m.chat];

  let option = {
    on: true,
    off: false,
  }[args[0]?.toLowerCase()];

  if (option === undefined) {
    return m.reply(
      `📢 *${command.toUpperCase()} USAGE*\n\n` +
      `> *• Example:* ${usedPrefix + command} on\n` +
      `> *• Example:* ${usedPrefix + command} off`
    );
  }

  chat.antilinkch = option;

  await m.reply(
    option
      ? `✅ *Anti-Channel Link* feature has been *enabled* in this group.`
      : `✅ *Anti-Channel Link* feature has been *disabled* in this group.`
  );
};

handler.before = async function (m, { conn, isAdmin, isBotAdmin }) {
  if (!m.isGroup || m.isBaileys || m.fromMe) return true;

  const chat = global.db.data.chats[m.chat] || {};
  if (!chat.antilinkch) return;

  const regex = /https:\/\/whatsapp\.com\/channel\/[A-Za-z0-9]{22}/;
  const isChannelLink = regex.test(m.text);

  if (isChannelLink) {
    if (isAdmin) return;
    if (!isBotAdmin) return;

    await conn.sendMessage(
      m.chat,
      {
        text:
          `🚫 *Channel Link Detected!*\n\n` +
          `@${m.sender.split("@")[0]}, posting WhatsApp Channel links is not allowed in this group.\n` +
          `Your message has been delete.`,
        mentions: [m.sender],
      },
      { quoted: m }
    );

    await conn.sendMessage(m.chat, { delete: m.key });
  }
};

handler.command = ['antilinkch'];
handler.help = ['antilinkch'].map(v => v + ' *[on/off]*');
handler.tags = ['group'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;