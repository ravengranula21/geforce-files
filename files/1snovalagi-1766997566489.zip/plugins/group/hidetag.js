//© Suika-Bot 2024-2025
// • Credits : wa.me/6281949448422 [ Fahriganz ]
// • Owner: 6287860644193

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, { conn, text, participants, usedPrefix, command }) => {
    if (!text && !m.quoted) return m.reply(`*• Example :* ${usedPrefix + command} *[text/reply pesan]*`)
    if (m.quoted) {
        let qmsg = m.quoted.fakeObj ? m.quoted.fakeObj : m.quoted
        await conn.sendMessage(m.chat, {
            forward: qmsg,
            mentions: participants.map(a => a.id)
        }, { quoted: m })
    } else {
        await conn.sendMessage(m.chat, {
            text: text,
            mentions: participants.map(a => a.id)
        }, { quoted: m })
    }
}

handler.help = ["hidetag"].map(v => v + " *[text/reply]*")
handler.tags = ["group"]
handler.command = ["hidetag", "ht", "h"]
handler.group = true
handler.admin = true

export default handler