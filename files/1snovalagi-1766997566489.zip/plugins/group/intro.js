//© Suika-Bot 2024-2025
// • Credits : wa.me/6281949448422 [ Fahriganz ]
// • Owner: 6281949448422

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    conn.reply(
        m.chat,
        `╭─── *「 Kartu Intro 」*
│       
│ *Nama     :* 
│ *Gender   :* 
│ *Umur      :* 
│ *Hobby    :* 
│ *Kelas      :* 
│ *Asal         :* 
│ *Agama    :* 
│ *Status     :* 
╰──────────────`,
        m,
    );
};
handler.help = ["intro"].map((a) => a + " *[introduction ys]*");
handler.tags = ["group"];
handler.command = ["intro"];

export default handler;