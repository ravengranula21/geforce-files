let handler = async (
  m,
  { isAdmin, isOwner, isBotAdmin, conn, args, usedPrefix, command },
) => {
  let chat = global.db.data.chats[m.chat];
  let prefix = usedPrefix;
  let bu = `*[ ✓ ] Success turned on anti link on this group*`.trim();

  let isClose = {
    on: true,
    off: false,
  }[args[0] || ""];

  if (isClose === undefined) {
    let text5 = `*[ ${command.toUpperCase()} EXAMPLE ]*:
> *• Example :* ${usedPrefix + command} on
> *• Example :* ${usedPrefix + command} off`;

    await conn.sendMessage(m.chat, {
      text: text5,
      footer: "Choose an option below:",
      buttons: [
        {
          buttonId: `.antibot on`,
          buttonText: { displayText: "🟢 TURN ON" },
          type: 1,
        },
        {
          buttonId: `.antibot off`,
          buttonText: { displayText: "🔴 TURN OFF" },
          type: 1,
        },
      ],
      headerType: 1,
    });

    return;
  } else if (isClose === false) {
    chat.antiBot = isClose;
    await m.reply("*[ ✓ ] Successfully turned off anti link on this group*");
  } else if (isClose === true) {
    chat.antiBot = isClose;
    await m.reply(bu);
  }
};

handler.help = ["antibot *[on/off]*"];
handler.tags = ["group"];
handler.command = ["antibot"];
handler.group = true;
handler.admin = true;
handler.botAdmin = false;

export default handler;