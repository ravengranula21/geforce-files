let handler = async (m, { conn, args, usedPrefix, command}) => {
  if (!args[0]) return m.reply(`*• Example:* ${usedPrefix + command} *[url]*`)
  try {
    let ssUrl = `https://image.thum.io/get/fullpage/${args[0]}`
    await conn.sendMessage(m.chat, {
      image: { url: ssUrl },
      caption: global.wm
    }, { quoted: m })
  } catch {
    m.reply('Gagal mengambil screenshot')
  }
}

handler.help = ['ssweb'].map(v => v + '*[url]*');
handler.tags = ['internet']
handler.command = ['ssweb']

export default handler