let handler = async (m, { conn, usedPrefix, command }) => {
  if (!m.quoted) {
    return m.reply(`*• Example:* ${usedPrefix + command} *[reply sticker]*`)
  }

  const q = m.quoted
  const mime = q.mediaType || ''

  if (/webp/.test(mime)) {
    return m.reply("```----> Failed Execution ! Are you sure it's sticker?");
  }

  const media = await q.download()

  await conn.sendMessage(
    m.chat,
    {
      image: media,
      caption: global.wm
    },
    { quoted: m }
  )
}

handler.help = ['toimg'].map(v => v + ' *[reply sticker]*')
handler.tags = ['sticker']
handler.command = ['toimg']

export default handler