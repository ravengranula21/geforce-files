let handler = async (m, { usedPrefix: _p, command, text }) => {
  const user = global.db.data.users[m.sender]

  if (user.subscriber > 0) {
    return m.reply('[❗] Kamu sudah memiliki akun YouTube')
  }

  if (!text) {
    return m.reply(
      `[❗] Mau buat akun YouTube dengan nama apa?\n` +
      `Contoh: ${_p + command} Pemburu Loli`
    )
  }

  if (text.length > 20) {
    return m.reply('[❗] Maksimal 20 Karakter')
  }

  user.nameyt = text.trim()
  user.subscriber += 2

  const ytname = user.nameyt
  const subs = user.subscriber

  m.reply(`*[✔️] Sukses membuat akun YouTube*

┌∘ - Nama YT: ${ytname}
└∘ - Subscriber: ${subs}`)
}

handler.tags = ['rpg', 'game']
handler.help = ['createyt']
handler.command = /^(createyt|buatyt)$/i
handler.register = true

export default handler