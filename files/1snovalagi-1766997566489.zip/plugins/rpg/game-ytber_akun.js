let handler = async (m, { command, conn }) => {
  try {
    const user = global.db.data.users[m.sender]

    const nama = user.name || 'Tidak diketahui'
    const namayt = user.nameyt || ''
    const bsubs = user.subscriber || 0
    const blike = user.liketotal || 0
    const spbutton = user.silverplaybutton || 0
    const gpbutton = user.goldplaybutton || 0
    const dpbutton = user.diamondplaybutton || 0

    if (!namayt) {
      return m.reply(
        "[❗] Kamu belum mempunyai akun youtube\n\n" +
        "buat akun youtube-mu menggunakan perintah:\n/buatyt"
      )
    }

    const subs = typeof bsubs === 'number' ? bsubs.toLocaleString() : '0'
    const like = typeof blike === 'number' ? blike.toLocaleString() : '0'

    const stt = `*📛 YOUTUBE - STUDIO 📛*

┌───[ *ɪɴғᴏ ᴀᴋᴜɴ ʏᴛ* ]
│• 👤 *Pemilik:* @${m.sender.replace(/@.+/, '')}
│• 🏷️ *Nama:* ${nama}
│• 🌐 *Nama Channel:* ${namayt}
│• 👥 *Subscribers:* ${subs}
│• 👍🏻 *Total like:* ${like}
└─⬤
┌───[ *ᴀᴄʜɪᴇᴍᴇɴᴛ* ]
│• ⬜ *Silver play button:* ${spbutton ? '✅' : 'Belum Punya'}
│• 🟨 *Gold play button:* ${gpbutton ? '✅' : 'Belum Punya'}
│• 💎 *Diamond play button:* ${dpbutton ? '✅' : 'Belum Punya'}
└─⬤`

    await conn.sendMessage(
      m.chat,
      {
        text: stt,
        contextInfo: {
          mentionedJid: [m.sender],
          forwardingScore: 999,
          isForwarded: false,
          forwardedNewsletterMessageInfo: {
            newsletterName: null,
            serverMessageId: null,
            newsletterJid: '0@newsletter'
          },
          externalAdReply: {
            title: 'Y O U T U B E - S T U D I O',
            body: 'official account YouTube of ' + namayt,
            thumbnailUrl: 'https://files.catbox.moe/j9esdj.jpg',
            sourceUrl: '',
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      },
      { quoted: m }
    )
  } catch (err) {
    console.error(err)
    m.reply('Terjadi kesalahan: ' + err.message)
  }
}

handler.tags = ['rpg']
handler.help = ['akunyt']
handler.command = /^(akunyt)$/i
handler.register = true

export default handler