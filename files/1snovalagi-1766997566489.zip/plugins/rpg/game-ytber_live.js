let handler = async (m, { conn, text }) => {
  const user = global.db.data.users[m.sender]
  const name = user.name
  const awalSubs = user.subscriber || 0

  user.subscriber ||= 0
  user.like ||= 0
  user.liketotal ||= 0
  user.money ||= 0
  user.bank ||= 0
  user.lastlive ||= 0
  user.silverplaybutton ||= 0
  user.goldplaybutton ||= 0
  user.diamondplaybutton ||= 0

  if (user.subscriber === 0) {
    return conn.reply(
      m.chat,
      `[❗] Kamu tidak memiliki akun YouTube\n\nKetik: .buatyt`,
      m
    )
  }

  const cooldown = 500000
  const elapsed = Date.now() - user.lastlive
  if (elapsed < cooldown) {
    return m.reply(
      `[❗] Hari ini kamu sudah live YouTube\n` +
      `Silahkan beristirahat selama ${clockString(cooldown - elapsed)}`
    )
  }

  if (!text) {
    return conn.reply(
      m.chat,
      `[🔴] Judul Live nya apa?\nContoh: .live Mandi bareng alya`,
      m
    )
  }

  if (text.length > 25) {
    return conn.reply(
      m.chat,
      `[❗] Panjang Judul Maksimal 25 Karakter`,
      m
    )
  }

  let money = 0
  let subs = 0
  let like = 0
  let donate = 0

  if (user.subscriber > 10_000_000) {
    money = rand(5_000_000)
    subs = rand(10_000)
    like = rand(600_000)
    donate = rand(1_500_000)

    if (!user.diamondplaybutton) {
      user.diamondplaybutton = 1
      conn.reply(
        m.chat,
        `[❗] *Selamat ${name}*\nKamu mendapatkan 💎 Diamond Play Button!\n(${awalSubs.toLocaleString()} Subs)`,
        m
      )
    }
  } else if (user.subscriber > 1_000_000) {
    money = rand(500_000)
    subs = rand(6_000)
    like = rand(300_000)
    donate = rand(5_500_000)

    if (!user.goldplaybutton) {
      user.goldplaybutton = 1
      conn.reply(
        m.chat,
        `[❗] *Selamat ${name}*\nKamu mendapatkan 🥇 Gold Play Button!\n(${awalSubs.toLocaleString()} Subs)`,
        m
      )
    }
  } else if (user.subscriber > 500_000) {
    money = rand(230_000)
    subs = rand(2_000)
    like = rand(5_000)
    donate = rand(250_000)
  } else if (user.subscriber > 100_000) {
    money = rand(150_000)
    subs = rand(1_000)
    like = rand(30_000)
    donate = rand(150_000)

    if (!user.silverplaybutton) {
      user.silverplaybutton = 1
      conn.reply(
        m.chat,
        `[❗] *Selamat ${name}*\nKamu mendapatkan 🥈 Silver Play Button!\n(${awalSubs.toLocaleString()} Subs)`,
        m
      )
    }
  } else if (user.subscriber > 50_000) {
    money = rand(80_000)
    subs = rand(500)
    like = rand(3_000)
    donate = rand(90_000)
  } else if (user.subscriber > 10_000) {
    money = rand(60_000)
    subs = rand(200)
    like = rand(2_000)
    donate = rand(70_000)
  } else if (user.subscriber > 1_000) {
    money = rand(30_000)
    subs = rand(130)
    like = rand(1_000)
    donate = rand(45_000)
  } else if (user.subscriber > 100) {
    money = rand(15_000)
    subs = rand(90)
    like = rand(500)
    donate = rand(25_000)
  } else {
    money = rand(5_000)
    subs = rand(50)
    like = rand(100)
    donate = rand(15_000)
  }

  user.money += money
  user.subscriber += subs
  user.like += like
  user.liketotal += like
  user.bank += donate
  user.lastlive = Date.now()

  const mentionedJid = [m.sender]

  const result = `[ 🔴 *LIVE YOUTUBE* ]

┌──[ *Hasil Streaming* ]
│👤 *Streamer:* @${m.sender.replace(/@.+/, '')}
│📹 *Judul:* ${text}
│💸 *Money:* +${money.toLocaleString()}
│💳 *Donasi:* +${donate.toLocaleString()}
│👥 *Subscriber:* +${subs.toLocaleString()}
│👍🏻 *Like:* +${like.toLocaleString()}
└┬──⬤
  │📊 *Total Like:* ${user.liketotal.toLocaleString()}
  │📈 *Total Subscriber:* ${user.subscriber.toLocaleString()}
  └────⬤

Cek akun YouTube:
_.akunyt_`

  conn.reply(m.chat, result, m, { contextInfo: { mentionedJid } })

  setTimeout(() => {
    conn.reply(
      m.chat,
      `[❗] Hei @${m.sender.replace(/@.+/, '')}, subscribersmu menunggumu!\nAyo live lagi 🔴`,
      m,
      { contextInfo: { mentionedJid } }
    )
  }, 600000)
}

handler.tags = ['rpg', 'game']
handler.help = ['live', 'streaming']
handler.command = /^(live|streaming)$/i
handler.register = true
handler.group = true

export default handler

function rand(max) {
  return Math.floor(Math.random() * max)
}

function clockString(ms) {
  const h = Math.floor(ms / 3600000) % 60
  const m = Math.floor(ms / 60000) % 60
  const s = Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}