import fs from 'fs'
import archiver from 'archiver'
import cron from 'node-cron'

const owner = global.owner + '@s.whatsapp.net'
let lock = false

const bar = p => {
  const max = 10
  const fill = Math.floor(p / (100 / max))
  return '█'.repeat(fill) + '░'.repeat(max - fill)
}

const cleanOld = () => {
  fs.readdirSync('./')
    .filter(v => v.startsWith('backup_') && v.endsWith('.zip'))
    .forEach(v => fs.unlinkSync(v))
}

const backup = async (conn, chat = owner) => {
  if (lock) return
  lock = true
  cleanOld()

  const msg = await conn.sendMessage(chat, { text: '⏳ Backup\n░░░░░░░░░░ 0%' })
  const name = `backup_${Date.now()}.zip`
  const out = fs.createWriteStream(name)
  const zip = archiver('zip')

  zip.on('progress', p => {
    const percent = Math.floor((p.fs.processedBytes / p.fs.totalBytes) * 100)
    conn.sendMessage(chat, {
      text: `⏳ Backup\n${bar(percent)} ${percent}%`,
      edit: msg.key
    })
  })

  zip.pipe(out)
  zip.glob('**/*', { ignore: ['node_modules/**', 'sessions/**', 'tmp/**', 'backup_*.zip'] })
  zip.finalize()

  out.on('close', () => {
    conn.sendFile(chat, name, name, '✅ Backup selesai')
    lock = false
  })
}

let handler = async (m, { conn }) => {
  if (m.sender === owner) backup(conn, m.chat)
}

handler.help = ["backup *[send backup script]*"]
handler.command = ["backup"];
handler.tags = ["owner"];
handler.owner = true
handler.private = true

export default handler

cron.schedule('0 */6 * * *', () => backup(global.conn))