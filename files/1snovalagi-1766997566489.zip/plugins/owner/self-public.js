//© Shima-Bot 2024-2025
// • Credits : wa.me/6281949448422 [ Fahriganz ]
// • Owner: 6287860644193

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, {
    conn,
    command
}) => {
    let isPublic = command === "public";
    let self = global.opts["self"]

    if (self === !isPublic) return m.reply(`Is it ${!isPublic ? "Self" : "Public"} from earlier ${m.sender.split("@")[0] === global.owner[1] ? "Sister" : "Brother"}`)
    global.opts["self"] = !isPublic
    m.reply(`Success *${!isPublic ? "Self" : "Public"}* bot!`)
}

handler.help = ["self", "public"].map(a => a + ' *[options]*')
handler.tags = ["owner"]
handler.owner = true
handler.command = /^(self|public)/i

export default handler