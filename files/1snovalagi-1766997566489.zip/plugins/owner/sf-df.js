import fs from 'fs'
import { createRequire } from 'module'
const require = createRequire(import.meta.url)
const beautify = require('js-beautify').js

let handler = async (m, { text, usedPrefix, command, conn }) => {
  if (!text) throw `*• Example:* ${usedPrefix + command} *[filename]*`

  const pluginsFolder = 'plugins'

  if (!fs.existsSync(pluginsFolder)) {
    return conn.sendMessage(m.chat, { text: '*[ FOLDER DOES NOT EXIST ]*' }, { quoted: m })
  }

  if (command === 'sf') {
    if (!m.quoted) return m.reply(`*[ ! ] Reply Your Progress Code*`)
    let path = `${pluginsFolder}/${text}`
    fs.writeFileSync(
      path,
      beautify(`//• © Sovia Project
// • Credits : wa.me/6281949448422 [ Fahriganz ]
// • Owner : ${global.nomorown}
// • Fitur : ${text}

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/
${m.quoted.text}`)
    )
    let key = await conn.sendMessage(m.chat, { text: '*[ SAVING CODE... ]*' }, { quoted: m })
    await conn.sendMessage(
      m.chat,
      {
        text: `*[ SUCCESS SAVING CODE ]*`,
        edit: key.key
      },
      { quoted: m }
    )
  } else if (command === 'df') {
    let path = `${pluginsFolder}/${text}`
    let key = await conn.sendMessage(m.chat, { text: '*[ DELETE FILE... ]*' }, { quoted: m })
    if (!fs.existsSync(path))
      return conn.sendMessage(
        m.chat,
        {
          text: '*[ FILE NOT FOUND ]*',
          edit: key.key
        },
        { quoted: m }
      )
    fs.unlinkSync(path)
    await conn.sendMessage(
      m.chat,
      {
        text: '*[ SUCCESS DELETE FILE ]*',
        edit: key.key
      },
      { quoted: m }
    )
  }
}

handler.help = ['sf', 'df'].map((v) => v + ' *[reply code/filename]*')
handler.tags = ['owner']
handler.command = /^(sf|df)$/i
handler.owner = true

export default handler