import jimp from 'jimp'
import { S_WHATSAPP_NET } from 'baileys'

let handler = async (m, { conn, command, usedPrefix }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || q.mediaType || ''

  m.reply("```[ ! ] Wait...```<")
  if (/image/g.test(mime) && !/webp/g.test(mime)) {
    try {
      let media = await q.download()
      let botNumber = conn.user.jid
      let { img } = await profilePicture(media)
      await conn.query({
        tag: 'iq',
        attrs: {
          to: S_WHATSAPP_NET,
          type: 'set',
          xmlns: 'w:profile:picture'
        },
        content: [
          {
            tag: 'picture',
            attrs: { type: 'image' },
            content: img
          }
        ]
      })
      m.reply('*✅ Successfully replaced PP*')
    } catch (e) {
      console.error(e)
      m.reply('*An error occurred, please try again later.*')
    }
  } else {
    m.reply(`*• Example:* ${usedPrefix + command} *[send/reply image]*`)
  }
}

handler.help = ['setppbot *[send/reply image]*']
handler.tags = ['owner']
handler.command = ['setppbot']
handler.owner = true

export default handler

async function profilePicture(media) {
  const img = await jimp.read(media)
  const min = img.getWidth()
  const max = img.getHeight()
  const cropped = img.crop(0, 0, min, max)
  return {
    img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp.MIME_JPEG),
    preview: await cropped.normalize().getBufferAsync(jimp.MIME_JPEG)
  }
}